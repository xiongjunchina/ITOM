--
-- PostgreSQL database dump
--

\restrict F6sFYp573rcmoUOQASwckkMVBBgN9vwNIfMhe5EurZLXcaZo0vB9a1CHzIf1Uyp

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_campaign; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.activity_campaign (
    name character varying(200) NOT NULL,
    description text,
    period_label character varying(32) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    performance_ratio double precision NOT NULL,
    status character varying(16) NOT NULL,
    created_by character varying(26),
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean NOT NULL
);


ALTER TABLE public.activity_campaign OWNER TO aom;

--
-- Name: COLUMN activity_campaign.period_label; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.activity_campaign.period_label IS '考核期，如 2026-H2 / 2026-Q3';


--
-- Name: COLUMN activity_campaign.performance_ratio; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.activity_campaign.performance_ratio IS '绩效折算系数：绩效分=活动积分×系数';


--
-- Name: COLUMN activity_campaign.status; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.activity_campaign.status IS 'draft/active(上架)/offline(下架)';


--
-- Name: COLUMN activity_campaign.is_example; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.activity_campaign.is_example IS '示例数据：置顶展示且只读';


--
-- Name: attachment; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.attachment (
    entity_type character varying(32) NOT NULL,
    entity_id character varying(26) NOT NULL,
    filename character varying(255) NOT NULL,
    storage_path character varying(255) NOT NULL,
    size integer NOT NULL,
    uploaded_by character varying(26),
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.attachment OWNER TO aom;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.audit_log (
    entity_type character varying(32) NOT NULL,
    entity_id character varying(26) NOT NULL,
    action character varying(32) NOT NULL,
    actor character varying(26),
    actor_name character varying(64),
    summary jsonb,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.audit_log OWNER TO aom;

--
-- Name: COLUMN audit_log.actor; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.audit_log.actor IS 'auth_user.id';


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.auth_user (
    username character varying(64) NOT NULL,
    password_hash character varying(255) NOT NULL,
    person_id character varying(26),
    roles jsonb NOT NULL,
    is_active boolean NOT NULL,
    last_login_at timestamp without time zone,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    auth_source character varying(16) DEFAULT 'local'::character varying NOT NULL,
    external_id character varying(128),
    is_example boolean DEFAULT false NOT NULL,
    preferences jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.auth_user OWNER TO aom;

--
-- Name: business_domain; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.business_domain (
    code character varying(32) NOT NULL,
    name character varying(128) NOT NULL,
    description text,
    owner_id character varying(26),
    backup_owner_id character varying(26),
    sort integer NOT NULL,
    active boolean NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.business_domain OWNER TO aom;

--
-- Name: COLUMN business_domain.owner_id; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.business_domain.owner_id IS 'BP 负责人';


--
-- Name: business_domain_member; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.business_domain_member (
    domain_id character varying(26) NOT NULL,
    person_id character varying(26) NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.business_domain_member OWNER TO aom;

--
-- Name: campaign_task; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.campaign_task (
    campaign_id character varying(26) NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    points double precision NOT NULL,
    max_times integer NOT NULL,
    sort integer NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean NOT NULL
);


ALTER TABLE public.campaign_task OWNER TO aom;

--
-- Name: COLUMN campaign_task.description; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.campaign_task.description IS '贡献指标说明/达成标准';


--
-- Name: COLUMN campaign_task.points; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.campaign_task.points IS '每次完成奖励积分';


--
-- Name: COLUMN campaign_task.max_times; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.campaign_task.max_times IS '每人可获奖次数上限，0=不限';


--
-- Name: COLUMN campaign_task.is_example; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.campaign_task.is_example IS '示例数据：置顶展示且只读';


--
-- Name: ci; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.ci (
    ci_code character varying(32) NOT NULL,
    name character varying(128) NOT NULL,
    category character varying(32) NOT NULL,
    status character varying(16) NOT NULL,
    owner character varying(26) NOT NULL,
    environment character varying(16),
    business_owner character varying(64),
    vendor_id character varying(26),
    description text,
    launch_date date,
    attrs jsonb,
    remarks text,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ci OWNER TO aom;

--
-- Name: COLUMN ci.category; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ci.category IS '应用/服务器/云资源/网络/安全/协作/终端/基础设施/咨询';


--
-- Name: COLUMN ci.status; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ci.status IS '运行中/维护中/已下线';


--
-- Name: COLUMN ci.environment; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ci.environment IS '生产/测试/开发';


--
-- Name: COLUMN ci.attrs; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ci.attrs IS '类别专属属性';


--
-- Name: ci_relationship; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.ci_relationship (
    source_ci_id character varying(26) NOT NULL,
    target_ci_id character varying(26) NOT NULL,
    relation_type character varying(16) NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ci_relationship OWNER TO aom;

--
-- Name: COLUMN ci_relationship.relation_type; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ci_relationship.relation_type IS '运行于/依赖/连接';


--
-- Name: contract; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.contract (
    code character varying(32) NOT NULL,
    name character varying(200) NOT NULL,
    vendor_id character varying(26) NOT NULL,
    amount_10k double precision,
    start_date date NOT NULL,
    end_date date NOT NULL,
    owner character varying(26),
    remarks text,
    expiry_warned boolean NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.contract OWNER TO aom;

--
-- Name: COLUMN contract.amount_10k; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.contract.amount_10k IS '金额(万元)';


--
-- Name: COLUMN contract.expiry_warned; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.contract.expiry_warned IS '到期预警已发';


--
-- Name: cost_entry; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.cost_entry (
    project_id character varying(26) NOT NULL,
    entry_date date NOT NULL,
    amount_10k double precision NOT NULL,
    note character varying(200),
    created_by character varying(26),
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.cost_entry OWNER TO aom;

--
-- Name: COLUMN cost_entry.amount_10k; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.cost_entry.amount_10k IS '金额(万元)';


--
-- Name: department; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.department (
    code character varying(32) NOT NULL,
    name character varying(128) NOT NULL,
    parent_id character varying(26),
    dept_type character varying(16) NOT NULL,
    external_source character varying(16),
    external_id character varying(128),
    sort integer NOT NULL,
    active boolean NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.department OWNER TO aom;

--
-- Name: COLUMN department.dept_type; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.department.dept_type IS 'it/business/audit';


--
-- Name: COLUMN department.external_source; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.department.external_source IS '同步来源预留：feishu/ad';


--
-- Name: COLUMN department.external_id; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.department.external_id IS '外部组织节点 ID 预留';


--
-- Name: development_activity; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.development_activity (
    activity_type character varying(32) NOT NULL,
    topic character varying(200) NOT NULL,
    activity_date date NOT NULL,
    host_id character varying(26),
    participant_ids jsonb,
    output_link character varying(500),
    remarks text,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean NOT NULL
);


ALTER TABLE public.development_activity OWNER TO aom;

--
-- Name: COLUMN development_activity.activity_type; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.development_activity.activity_type IS '内部交叉培训/外部技术交流/新技术研究';


--
-- Name: COLUMN development_activity.host_id; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.development_activity.host_id IS '主讲/组织人';


--
-- Name: COLUMN development_activity.output_link; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.development_activity.output_link IS '产出链接（课件/纪要/报告）';


--
-- Name: COLUMN development_activity.is_example; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.development_activity.is_example IS '示例数据：置顶展示且只读';


--
-- Name: hiring_need; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.hiring_need (
    position_id character varying(26) NOT NULL,
    headcount integer NOT NULL,
    status character varying(16) NOT NULL,
    progress_note character varying(200),
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean NOT NULL,
    level character varying(8) DEFAULT '中级'::character varying NOT NULL,
    qualification text
);


ALTER TABLE public.hiring_need OWNER TO aom;

--
-- Name: COLUMN hiring_need.status; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.hiring_need.status IS '待招聘/面试中/已到岗/已取消';


--
-- Name: COLUMN hiring_need.progress_note; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.hiring_need.progress_note IS '进度备注';


--
-- Name: COLUMN hiring_need.is_example; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.hiring_need.is_example IS '示例数据：置顶展示且只读';


--
-- Name: idea; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.idea (
    idea_code character varying(32) NOT NULL,
    title character varying(200) NOT NULL,
    content text NOT NULL,
    proposer character varying(26),
    proposer_name character varying(64),
    status character varying(16) NOT NULL,
    like_count integer NOT NULL,
    adopted_at timestamp without time zone,
    decline_reason text,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean NOT NULL
);


ALTER TABLE public.idea OWNER TO aom;

--
-- Name: COLUMN idea.proposer; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.idea.proposer IS 'auth_user.id';


--
-- Name: COLUMN idea.status; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.idea.status IS 'submitted/adopted/implemented/declined';


--
-- Name: COLUMN idea.is_example; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.idea.is_example IS '示例数据：置顶展示且只读';


--
-- Name: idea_like; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.idea_like (
    idea_id character varying(26) NOT NULL,
    voter character varying(26) NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean NOT NULL
);


ALTER TABLE public.idea_like OWNER TO aom;

--
-- Name: COLUMN idea_like.voter; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.idea_like.voter IS 'auth_user.id';


--
-- Name: COLUMN idea_like.is_example; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.idea_like.is_example IS '示例数据：置顶展示且只读';


--
-- Name: in_app_notification; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.in_app_notification (
    recipient character varying(26) NOT NULL,
    title character varying(200) NOT NULL,
    content text,
    link character varying(200),
    read_at timestamp without time zone,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.in_app_notification OWNER TO aom;

--
-- Name: COLUMN in_app_notification.link; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.in_app_notification.link IS '前端路由';


--
-- Name: knowledge_article; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.knowledge_article (
    article_code character varying(32) NOT NULL,
    title character varying(200) NOT NULL,
    content text NOT NULL,
    tags jsonb,
    status character varying(16) NOT NULL,
    author character varying(26),
    author_name character varying(64),
    view_count integer NOT NULL,
    helpful_count integer NOT NULL,
    linked_ticket_ids jsonb,
    source_requirement_id character varying(26),
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    content_format character varying(8) DEFAULT 'markdown'::character varying NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.knowledge_article OWNER TO aom;

--
-- Name: COLUMN knowledge_article.content; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.knowledge_article.content IS 'Markdown';


--
-- Name: COLUMN knowledge_article.status; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.knowledge_article.status IS 'draft/published';


--
-- Name: COLUMN knowledge_article.author; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.knowledge_article.author IS 'auth_user.id';


--
-- Name: COLUMN knowledge_article.source_requirement_id; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.knowledge_article.source_requirement_id IS '需求经验转入(M5)';


--
-- Name: knowledge_vote; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.knowledge_vote (
    article_id character varying(26) NOT NULL,
    person character varying(26) NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.knowledge_vote OWNER TO aom;

--
-- Name: COLUMN knowledge_vote.person; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.knowledge_vote.person IS 'auth_user.id（requester 也可点有用）';


--
-- Name: master_data; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.master_data (
    category character varying(64) NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    sort integer NOT NULL,
    active boolean NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.master_data OWNER TO aom;

--
-- Name: milestone; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.milestone (
    project_id character varying(26) NOT NULL,
    name character varying(200) NOT NULL,
    target_date date NOT NULL,
    description text,
    achieved_at date,
    overdue_warned boolean NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.milestone OWNER TO aom;

--
-- Name: COLUMN milestone.overdue_warned; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.milestone.overdue_warned IS '逾期告警已发';


--
-- Name: notification_outbox; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.notification_outbox (
    event_type character varying(64) NOT NULL,
    entity_type character varying(32),
    entity_id character varying(26),
    payload jsonb,
    channel character varying(16) NOT NULL,
    status character varying(16) NOT NULL,
    sent_at timestamp without time zone,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.notification_outbox OWNER TO aom;

--
-- Name: COLUMN notification_outbox.channel; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.notification_outbox.channel IS 'in_app/feishu…';


--
-- Name: COLUMN notification_outbox.status; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.notification_outbox.status IS 'pending/sent/failed';


--
-- Name: org_member; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.org_member (
    name character varying(64) NOT NULL,
    position_id character varying(26),
    status character varying(16) NOT NULL,
    hire_date date,
    email character varying(128),
    feishu_user_id character varying(64),
    skills jsonb,
    remarks text,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    name_en character varying(64),
    department_id character varying(26),
    mobile character varying(32),
    external_source character varying(16),
    external_id character varying(128),
    employee_no character varying(32),
    gender character varying(8),
    birth_date date,
    employment_type character varying(16),
    supervisor_id character varying(26),
    work_location character varying(64),
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.org_member OWNER TO aom;

--
-- Name: COLUMN org_member.status; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.org_member.status IS '在岗/离职';


--
-- Name: COLUMN org_member.feishu_user_id; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.org_member.feishu_user_id IS '飞书集成预留';


--
-- Name: perf_adjustment; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.perf_adjustment (
    period character varying(32) NOT NULL,
    person_id character varying(26) NOT NULL,
    kind character varying(8) NOT NULL,
    points double precision NOT NULL,
    reason character varying(200) NOT NULL,
    created_by character varying(26),
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean NOT NULL
);


ALTER TABLE public.perf_adjustment OWNER TO aom;

--
-- Name: COLUMN perf_adjustment.kind; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.perf_adjustment.kind IS 'bonus 加分 / penalty 扣分';


--
-- Name: COLUMN perf_adjustment.points; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.perf_adjustment.points IS '正数；扣分在计算时取负';


--
-- Name: COLUMN perf_adjustment.reason; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.perf_adjustment.reason IS '加减分事项说明（必填）';


--
-- Name: COLUMN perf_adjustment.is_example; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.perf_adjustment.is_example IS '示例数据：置顶展示且只读';


--
-- Name: perf_override; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.perf_override (
    period character varying(32) NOT NULL,
    person_id character varying(26) NOT NULL,
    dimension_code character varying(48) NOT NULL,
    score double precision NOT NULL,
    created_by character varying(26),
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean NOT NULL
);


ALTER TABLE public.perf_override OWNER TO aom;

--
-- Name: COLUMN perf_override.score; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.perf_override.score IS '核定分 0-100';


--
-- Name: COLUMN perf_override.is_example; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.perf_override.is_example IS '示例数据：置顶展示且只读';


--
-- Name: perf_scheme; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.perf_scheme (
    name character varying(128) NOT NULL,
    description text,
    position_ids jsonb,
    dimensions jsonb,
    is_default boolean NOT NULL,
    active boolean NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean NOT NULL
);


ALTER TABLE public.perf_scheme OWNER TO aom;

--
-- Name: COLUMN perf_scheme.position_ids; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.perf_scheme.position_ids IS '适用岗位 id 列表';


--
-- Name: COLUMN perf_scheme.dimensions; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.perf_scheme.dimensions IS '[{"code","weight"}]';


--
-- Name: COLUMN perf_scheme.is_default; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.perf_scheme.is_default IS '未匹配岗位的兜底方案，全局唯一';


--
-- Name: COLUMN perf_scheme.is_example; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.perf_scheme.is_example IS '示例数据：置顶展示且只读';


--
-- Name: point_entry; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.point_entry (
    person_id character varying(26) NOT NULL,
    points double precision NOT NULL,
    source_type character varying(48) NOT NULL,
    source_ref character varying(26),
    campaign_id character varying(26),
    task_id character varying(26),
    period character varying(32),
    note character varying(200),
    created_by character varying(26),
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean NOT NULL
);


ALTER TABLE public.point_entry OWNER TO aom;

--
-- Name: COLUMN point_entry.source_type; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.point_entry.source_type IS 'campaign_award/idea_adopt/idea_like/manual/…';


--
-- Name: COLUMN point_entry.source_ref; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.point_entry.source_ref IS '来源单据/任务 id';


--
-- Name: COLUMN point_entry.period; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.point_entry.period IS '计入考核期';


--
-- Name: COLUMN point_entry.is_example; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.point_entry.is_example IS '示例数据：置顶展示且只读';


--
-- Name: point_rule; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.point_rule (
    code character varying(48) NOT NULL,
    name character varying(128) NOT NULL,
    points double precision NOT NULL,
    active boolean NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean NOT NULL
);


ALTER TABLE public.point_rule OWNER TO aom;

--
-- Name: COLUMN point_rule.is_example; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.point_rule.is_example IS '示例数据：置顶展示且只读';


--
-- Name: portfolio; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.portfolio (
    name character varying(128) NOT NULL,
    owner_id character varying(26),
    year character varying(8),
    description text,
    sort integer NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.portfolio OWNER TO aom;

--
-- Name: COLUMN portfolio.year; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.portfolio.year IS '年度，如 2026';


--
-- Name: position; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public."position" (
    name character varying(64) NOT NULL,
    duties text,
    headcount integer NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public."position" OWNER TO aom;

--
-- Name: COLUMN "position".duties; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public."position".duties IS '分工职责';


--
-- Name: COLUMN "position".headcount; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public."position".headcount IS '编制数';


--
-- Name: problem; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.problem (
    problem_code character varying(32) NOT NULL,
    title character varying(200) NOT NULL,
    description text NOT NULL,
    priority character varying(8) NOT NULL,
    status character varying(32) NOT NULL,
    service_item_id character varying(26),
    root_cause text,
    workaround text,
    owner character varying(26),
    source_ticket_id character varying(26),
    source_requirement_id character varying(26),
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.problem OWNER TO aom;

--
-- Name: COLUMN problem.root_cause; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.problem.root_cause IS '转已知错误时必填';


--
-- Name: COLUMN problem.source_ticket_id; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.problem.source_ticket_id IS '工单升级来源';


--
-- Name: COLUMN problem.source_requirement_id; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.problem.source_requirement_id IS '需求遗留转入(M5)';


--
-- Name: problem_ticket; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.problem_ticket (
    problem_id character varying(26) NOT NULL,
    ticket_id character varying(26) NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.problem_ticket OWNER TO aom;

--
-- Name: process_definition; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.process_definition (
    code character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    entity_type character varying(32) NOT NULL,
    trigger_condition jsonb,
    version integer NOT NULL,
    active boolean NOT NULL,
    description text,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.process_definition OWNER TO aom;

--
-- Name: COLUMN process_definition.entity_type; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.process_definition.entity_type IS 'ticket/requirement/project…';


--
-- Name: COLUMN process_definition.trigger_condition; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.process_definition.trigger_condition IS '如 {"ticket_type":"change"}';


--
-- Name: process_instance; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.process_instance (
    definition_id character varying(26) NOT NULL,
    entity_type character varying(32) NOT NULL,
    entity_id character varying(26) NOT NULL,
    status character varying(16) NOT NULL,
    current_step_seq integer NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.process_instance OWNER TO aom;

--
-- Name: COLUMN process_instance.status; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.process_instance.status IS '进行中/已完成/已终止';


--
-- Name: process_step; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.process_step (
    definition_id character varying(26) NOT NULL,
    seq integer NOT NULL,
    name character varying(128) NOT NULL,
    default_role character varying(32),
    autonomy_level character varying(4) NOT NULL,
    sla_hours double precision,
    description text,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    cc_roles jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.process_step OWNER TO aom;

--
-- Name: COLUMN process_step.default_role; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.process_step.default_role IS 'it_bp/it_pdm/it_pm/it_dev/it_ops/is_mgr/manager';


--
-- Name: COLUMN process_step.autonomy_level; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.process_step.autonomy_level IS 'L1-L4';


--
-- Name: process_task; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.process_task (
    instance_id character varying(26) NOT NULL,
    step_id character varying(26) NOT NULL,
    assignee character varying(26),
    status character varying(16) NOT NULL,
    started_at timestamp without time zone,
    due_at timestamp without time zone,
    completed_at timestamp without time zone,
    comment text,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.process_task OWNER TO aom;

--
-- Name: COLUMN process_task.status; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.process_task.status IS '待处理/已完成/已跳过';


--
-- Name: COLUMN process_task.due_at; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.process_task.due_at IS '按步骤 SLA';


--
-- Name: project; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.project (
    project_code character varying(32) NOT NULL,
    name character varying(200) NOT NULL,
    pm character varying(26) NOT NULL,
    status character varying(32) NOT NULL,
    planned_start date NOT NULL,
    planned_end date NOT NULL,
    actual_start date,
    actual_end date,
    portfolio_id character varying(26),
    service_item_id character varying(26),
    budget_10k double precision,
    description text,
    latest_update text,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.project OWNER TO aom;

--
-- Name: COLUMN project.pm; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.project.pm IS '项目经理';


--
-- Name: COLUMN project.actual_start; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.project.actual_start IS '[计] 转进行中打点';


--
-- Name: COLUMN project.actual_end; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.project.actual_end IS '[计] 转已完成打点';


--
-- Name: COLUMN project.budget_10k; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.project.budget_10k IS '预算(万元)';


--
-- Name: COLUMN project.latest_update; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.project.latest_update IS '最新动态一句话';


--
-- Name: provision_rule; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.provision_rule (
    match_type character varying(16) NOT NULL,
    match_value character varying(128) NOT NULL,
    default_roles jsonb NOT NULL,
    sort integer NOT NULL,
    active boolean NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.provision_rule OWNER TO aom;

--
-- Name: COLUMN provision_rule.match_type; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.provision_rule.match_type IS 'dept_type/department';


--
-- Name: COLUMN provision_rule.match_value; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.provision_rule.match_value IS 'dept_type 值或 department.id';


--
-- Name: COLUMN provision_rule.sort; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.provision_rule.sort IS '小号优先，命中即停';


--
-- Name: requirement; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.requirement (
    requirement_code character varying(32) NOT NULL,
    title character varying(200) NOT NULL,
    req_type character varying(16) NOT NULL,
    business_domain_id character varying(26) NOT NULL,
    description text NOT NULL,
    source character varying(32),
    requester character varying(26),
    requester_name character varying(64),
    moscow character varying(2),
    owner character varying(26),
    target_date date,
    solution text,
    acceptance_criteria jsonb,
    project_id character varying(26),
    status character varying(32) NOT NULL,
    registered_at timestamp without time zone,
    analyzing_at timestamp without time zone,
    implementing_at timestamp without time zone,
    closed_at timestamp without time zone,
    closure_note text,
    parent_requirement_id character varying(26),
    remarks text,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.requirement OWNER TO aom;

--
-- Name: COLUMN requirement.req_type; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.requirement.req_type IS '业务/功能/数据/集成/合规';


--
-- Name: COLUMN requirement.source; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.requirement.source IS '需求来源(字典)';


--
-- Name: COLUMN requirement.requester; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.requirement.requester IS '提出人 auth_user.id';


--
-- Name: COLUMN requirement.moscow; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.requirement.moscow IS 'M/S/C/W';


--
-- Name: COLUMN requirement.owner; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.requirement.owner IS '负责人';


--
-- Name: COLUMN requirement.target_date; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.requirement.target_date IS '排期目标日期';


--
-- Name: COLUMN requirement.solution; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.requirement.solution IS '解决方案';


--
-- Name: COLUMN requirement.acceptance_criteria; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.requirement.acceptance_criteria IS '[{text, checked}]';


--
-- Name: COLUMN requirement.closure_note; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.requirement.closure_note IS '关闭说明/遗留说明';


--
-- Name: requirement_task; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.requirement_task (
    requirement_id character varying(26) NOT NULL,
    name character varying(200) NOT NULL,
    assignee character varying(26) NOT NULL,
    plan_date date,
    status character varying(16) NOT NULL,
    done_at timestamp without time zone,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.requirement_task OWNER TO aom;

--
-- Name: COLUMN requirement_task.status; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.requirement_task.status IS '待处理/进行中/已完成';


--
-- Name: risk; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.risk (
    project_id character varying(26) NOT NULL,
    title character varying(200) NOT NULL,
    probability character varying(8) NOT NULL,
    impact character varying(8) NOT NULL,
    mitigation text,
    status character varying(16) NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.risk OWNER TO aom;

--
-- Name: COLUMN risk.probability; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.risk.probability IS '高/中/低';


--
-- Name: COLUMN risk.impact; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.risk.impact IS '高/中/低';


--
-- Name: COLUMN risk.mitigation; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.risk.mitigation IS '应对措施';


--
-- Name: COLUMN risk.status; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.risk.status IS '开放/已关闭';


--
-- Name: role; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.role (
    code character varying(32) NOT NULL,
    name character varying(64) NOT NULL,
    description text,
    base_role character varying(32),
    is_builtin boolean NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.role OWNER TO aom;

--
-- Name: COLUMN role.base_role; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.role.base_role IS '自定义角色继承的内置角色 code；内置角色为空';


--
-- Name: role_permission; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.role_permission (
    role_code character varying(32) NOT NULL,
    module character varying(48) NOT NULL,
    actions jsonb NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.role_permission OWNER TO aom;

--
-- Name: service_catalog; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.service_catalog (
    code character varying(32) NOT NULL,
    name character varying(128) NOT NULL,
    tier character varying(16) NOT NULL,
    description text,
    sort integer NOT NULL,
    status character varying(16) NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.service_catalog OWNER TO aom;

--
-- Name: COLUMN service_catalog.tier; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.service_catalog.tier IS 'gold/silver/bronze';


--
-- Name: COLUMN service_catalog.status; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.service_catalog.status IS '上架/下架';


--
-- Name: service_item; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.service_item (
    item_code character varying(32) NOT NULL,
    name character varying(128) NOT NULL,
    catalog_id character varying(26) NOT NULL,
    service_type character varying(32),
    owner character varying(26),
    description text,
    sla_response_hours double precision,
    sla_resolution_hours double precision,
    target_audience character varying(128),
    status character varying(16) NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.service_item OWNER TO aom;

--
-- Name: COLUMN service_item.sla_response_hours; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.service_item.sla_response_hours IS '覆盖 SLA 策略，可空';


--
-- Name: sla_policy; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.sla_policy (
    priority character varying(8) NOT NULL,
    response_minutes integer NOT NULL,
    resolution_hours double precision NOT NULL,
    active boolean NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.sla_policy OWNER TO aom;

--
-- Name: COLUMN sla_policy.priority; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.sla_policy.priority IS 'P1-P4';


--
-- Name: team_charter; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.team_charter (
    vision text,
    goals text,
    principles text,
    updated_by character varying(26),
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean NOT NULL
);


ALTER TABLE public.team_charter OWNER TO aom;

--
-- Name: COLUMN team_charter.is_example; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.team_charter.is_example IS '示例数据：置顶展示且只读';


--
-- Name: ticket; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.ticket (
    ticket_code character varying(32) NOT NULL,
    title character varying(200) NOT NULL,
    ticket_type character varying(32) NOT NULL,
    priority character varying(8) NOT NULL,
    description text NOT NULL,
    service_item_id character varying(26) NOT NULL,
    assignee character varying(26),
    ci_id character varying(26),
    remarks text,
    change_type character varying(16),
    risk_level character varying(16),
    change_reason text,
    rollback_plan text,
    planned_start_at timestamp without time zone,
    planned_end_at timestamp without time zone,
    implementation_plan text,
    solution text,
    root_cause text,
    closure_code character varying(32),
    satisfaction integer,
    approved_by character varying(26),
    approved_at timestamp without time zone,
    approval_comment text,
    status character varying(32) NOT NULL,
    submitter character varying(26),
    submitter_name character varying(64),
    submitter_dept character varying(64),
    service_line character varying(64),
    submitted_at timestamp without time zone,
    first_response_at timestamp without time zone,
    resolved_at timestamp without time zone,
    closed_at timestamp without time zone,
    paused_minutes double precision NOT NULL,
    paused_started_at timestamp without time zone,
    reopen_count integer NOT NULL,
    first_time_fix boolean,
    sla_response_min double precision,
    sla_resolution_hours double precision,
    actual_response_min double precision,
    actual_resolution_hours double precision,
    sla_response_met boolean,
    sla_resolution_met boolean,
    sla_warned boolean NOT NULL,
    problem_id character varying(26),
    requirement_id character varying(26),
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ticket OWNER TO aom;

--
-- Name: COLUMN ticket.ticket_type; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ticket.ticket_type IS 'incident/service_request/change';


--
-- Name: COLUMN ticket.priority; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ticket.priority IS 'P1-P4';


--
-- Name: COLUMN ticket.ci_id; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ticket.ci_id IS 'M3 接 CMDB 外键';


--
-- Name: COLUMN ticket.change_type; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ticket.change_type IS '标准/普通/紧急';


--
-- Name: COLUMN ticket.risk_level; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ticket.risk_level IS '高/中/低';


--
-- Name: COLUMN ticket.solution; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ticket.solution IS '解决时必填';


--
-- Name: COLUMN ticket.closure_code; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ticket.closure_code IS '关闭时必填';


--
-- Name: COLUMN ticket.satisfaction; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ticket.satisfaction IS '1-5 星';


--
-- Name: COLUMN ticket.submitter; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ticket.submitter IS 'auth_user.id';


--
-- Name: COLUMN ticket.service_line; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ticket.service_line IS '服务项带出';


--
-- Name: COLUMN ticket.paused_minutes; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ticket.paused_minutes IS '挂起累计，SLA 扣除';


--
-- Name: COLUMN ticket.sla_warned; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ticket.sla_warned IS '临期升级已通知';


--
-- Name: COLUMN ticket.problem_id; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ticket.problem_id IS 'M3 接问题外键';


--
-- Name: COLUMN ticket.requirement_id; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.ticket.requirement_id IS 'M5 接需求外键';


--
-- Name: user_group; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.user_group (
    code character varying(32) NOT NULL,
    name character varying(64) NOT NULL,
    description text,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    roles jsonb DEFAULT '[]'::jsonb NOT NULL,
    owner_id character varying(26),
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.user_group OWNER TO aom;

--
-- Name: user_group_member; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.user_group_member (
    group_id character varying(26) NOT NULL,
    person_id character varying(26) NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.user_group_member OWNER TO aom;

--
-- Name: vendor; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.vendor (
    code character varying(32) NOT NULL,
    name character varying(128) NOT NULL,
    contact character varying(64),
    phone character varying(32),
    email character varying(128),
    service_scope text,
    rating character varying(8),
    status character varying(16) NOT NULL,
    remarks text,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.vendor OWNER TO aom;

--
-- Name: COLUMN vendor.rating; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.vendor.rating IS 'A/B/C/D';


--
-- Name: COLUMN vendor.status; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.vendor.status IS '合作中/已终止';


--
-- Name: wbs_task; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.wbs_task (
    project_id character varying(26) NOT NULL,
    parent_task_id character varying(26),
    wbs_code character varying(32) NOT NULL,
    name character varying(200) NOT NULL,
    assignee character varying(26) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    status character varying(16) NOT NULL,
    completed_at timestamp without time zone,
    description text,
    deliverable character varying(200),
    predecessor_ids jsonb,
    sort integer NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.wbs_task OWNER TO aom;

--
-- Name: COLUMN wbs_task.wbs_code; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.wbs_task.wbs_code IS '[计] 树位置自动生成，如 1.2.1';


--
-- Name: COLUMN wbs_task.status; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.wbs_task.status IS '未开始/进行中/已完成';


--
-- Name: COLUMN wbs_task.predecessor_ids; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.wbs_task.predecessor_ids IS '前置任务 id 列表';


--
-- Name: workflow_status; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.workflow_status (
    entity_type character varying(32) NOT NULL,
    code character varying(32) NOT NULL,
    name character varying(64) NOT NULL,
    is_initial boolean NOT NULL,
    is_terminal boolean NOT NULL,
    sort integer NOT NULL,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.workflow_status OWNER TO aom;

--
-- Name: workflow_transition; Type: TABLE; Schema: public; Owner: aom
--

CREATE TABLE public.workflow_transition (
    entity_type character varying(32) NOT NULL,
    from_code character varying(32) NOT NULL,
    to_code character varying(32) NOT NULL,
    allowed_roles jsonb,
    id character varying(26) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL,
    is_example boolean DEFAULT false NOT NULL
);


ALTER TABLE public.workflow_transition OWNER TO aom;

--
-- Name: COLUMN workflow_transition.allowed_roles; Type: COMMENT; Schema: public; Owner: aom
--

COMMENT ON COLUMN public.workflow_transition.allowed_roles IS '空=不限角色';


--
-- Data for Name: activity_campaign; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.activity_campaign (name, description, period_label, start_date, end_date, performance_ratio, status, created_by, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
【示例】团建活动方案策划	填写指引——活动说明建议包含：\n① 活动目的：征集下季度团建方案，提升团队凝聚力\n② 参与方式：任何成员均可提交方案/参与评选/协助执行\n③ 积分规则：完成下方激励任务由管理员核实后发放积分\n④ 绩效折算：本活动折算系数 0.1，即活动积分 × 0.1 计入 2026-H2 考核期绩效分\n（示例：拿满 105 分 → 绩效加 10.5 分）	2026-H2	2026-07-01	2026-12-31	0.1	active	\N	01KX8XERVYG5PM56G2G61A6QQR	2026-07-11 23:41:38.045139	2026-07-11 23:41:38.045139	f	t
\.


--
-- Data for Name: attachment; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.attachment (entity_type, entity_id, filename, storage_path, size, uploaded_by, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.audit_log (entity_type, entity_id, action, actor, actor_name, summary, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
idea	01KX8XM7YZYYV1B2EE4S1ZWVKE	create	01KX3WBGWCAWHXV6BHVBCQM71Z	admin	{"code": "ID-202607-0001"}	01KX8XM7Z2DHF0EWYMDD35KJXY	2026-07-11 23:44:37.334096	2026-07-11 23:44:37.334096	f	f
role_permission	cio	replace	01KX3WBGWCAWHXV6BHVBCQM71Z	admin	{"modules": 30}	01KXA15V50PQWKHKBHDEWPCS88	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
org_member	01KXB2VAGH6567JSZV8A7W3GRF	create	01KX3WBGWCAWHXV6BHVBCQM71Z	admin	{"name": "Test"}	01KXB2VAGK2GV5A72MV8B33FDC	2026-07-12 19:54:21.061304	2026-07-12 19:54:21.061304	f	f
org_member	01KXB2VAGH6567JSZV8A7W3GRF	delete	01KX3WBGWCAWHXV6BHVBCQM71Z	admin	{"name": "Test", "accounts_disabled": []}	01KXB5Q6SWFXV4S64NRYP6JFY8	2026-07-12 20:44:31.909439	2026-07-12 20:44:31.909439	f	f
perf_override	01KXB85CDWPQCPT8KPWYN7K40G	set	01KX3WBGWCAWHXV6BHVBCQM71Z	admin	{"dim": "ticket_service", "score": 85.0, "period": "2026-H2"}	01KXB85CDXV29N4T4NAB47E6RZ	2026-07-12 21:27:13.594445	2026-07-12 21:27:13.594445	f	f
perf_adjustment	01KXB85CEC5DFF3YNA544ME9TR	create	01KX3WBGWCAWHXV6BHVBCQM71Z	admin	{"kind": "bonus", "period": "2026-H2", "points": 5.0, "reason": "验证用-重保特殊贡献"}	01KXB85CED4YZHRMKE7FCH78S8	2026-07-12 21:27:13.611785	2026-07-12 21:27:13.611785	f	f
perf_override	01KXB85CDWPQCPT8KPWYN7K40G	clear	01KX3WBGWCAWHXV6BHVBCQM71Z	admin	{"dim": "ticket_service", "period": "2026-H2"}	01KXB85VXQ1GFNHRJW9KK452BQ	2026-07-12 21:27:29.462756	2026-07-12 21:27:29.462756	f	f
perf_adjustment	01KXB85CEC5DFF3YNA544ME9TR	delete	01KX3WBGWCAWHXV6BHVBCQM71Z	admin	{"reason": "验证用-重保特殊贡献"}	01KXB85VY8GK1JNXD4XF5Q0GJP	2026-07-12 21:27:29.479378	2026-07-12 21:27:29.479378	f	f
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.auth_user (username, password_hash, person_id, roles, is_active, last_login_at, id, created_at, updated_at, is_deleted, auth_source, external_id, is_example, preferences) FROM stdin;
admin	$2b$12$UHo4tmtUQRcY.vHYE6AcIuwdcExHYWD/8tn..Nk/Vh2Pkrvm176KO	\N	["admin"]	t	2026-07-12 21:58:27.633269	01KX3WBGWCAWHXV6BHVBCQM71Z	2026-07-10 00:46:10.659915	2026-07-12 22:06:54.56348	f	local	\N	f	{"dashboard_widgets": ["alerts", "service_overview", "itsm_service_request", "itsm_change", "itsm_incident", "itsm_problem", "project", "requirement", "team"]}
\.


--
-- Data for Name: business_domain; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.business_domain (code, name, description, owner_id, backup_owner_id, sort, active, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
demo_retail	【示例】零售业务线	填写指引：业务域=横向服务线。负责人（BM）总体负责该业务域的 IT 支持；请改为真实业务线并指定真实负责人	01KX8RX278M82TBT5HHQV14JX6	\N	99	t	01KX8RX279ZVVH658DZ9BEM0BX	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	f
\.


--
-- Data for Name: business_domain_member; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.business_domain_member (domain_id, person_id, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
\.


--
-- Data for Name: campaign_task; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.campaign_task (campaign_id, name, description, points, max_times, sort, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
01KX8XERVYG5PM56G2G61A6QQR	提交完整团建方案	填写指引：贡献指标要可核实——方案含预算明细、日程安排、场地备选；由管理员核实后发放	30	1	0	01KX8XERVZA7ABXBPDKYGVGEEF	2026-07-11 23:41:38.045139	2026-07-11 23:41:38.045139	f	t
01KX8XERVYG5PM56G2G61A6QQR	方案被评选采纳	填写指引：结果型指标分值应高于过程型——最终被采纳执行的方案额外奖励	50	1	1	01KX8XERVZ602K39BWBHV2HEMM	2026-07-11 23:41:38.045139	2026-07-11 23:41:38.045139	f	t
01KX8XERVYG5PM56G2G61A6QQR	参与方案投票与评论反馈	填写指引：轻量参与型任务用低分+多次数鼓励广泛参与（每次 5 分，最多 3 次）	5	3	2	01KX8XERVZRNMSD86G593BTZFB	2026-07-11 23:41:38.045139	2026-07-11 23:41:38.045139	f	t
01KX8XERVYG5PM56G2G61A6QQR	活动现场组织与执行贡献	填写指引：执行型贡献按实际承担核发（物料/签到/摄影/主持等，每项 20 分，最多 2 项）	20	2	3	01KX8XERVZWPKT9FGX30AAWMXX	2026-07-11 23:41:38.045139	2026-07-11 23:41:38.045139	f	t
\.


--
-- Data for Name: ci; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.ci (ci_code, name, category, status, owner, environment, business_owner, vendor_id, description, launch_date, attrs, remarks, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
CI-DEMO	【示例】ERP 应用服务器	服务器	运行中	01KX8RX278M82TBT5HHQV14JX6	生产	填写指引：写业务侧负责人姓名	01KX8RX27BF3PMW8Z4J8E6RYX1	填写指引：描述该配置项的用途与位置，如：ERP 生产应用服务器，机房 A-3 机柜	2025-12-23	{"IP": "10.0.0.10", "配置": "8C32G（填写指引：类别专属属性按需添加键值，如服务器记录 IP/配置，应用记录技术栈）"}	填写指引：CI 关系（运行于/依赖/连接）在详情页影响分析中维护，用于故障影响评估	01KX8RX27C6ZT0Q9JK9JXMB32Z	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	t
\.


--
-- Data for Name: ci_relationship; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.ci_relationship (source_ci_id, target_ci_id, relation_type, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
\.


--
-- Data for Name: contract; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.contract (code, name, vendor_id, amount_10k, start_date, end_date, owner, remarks, expiry_warned, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
CT-DEMO	【示例】数据库年度维保合同	01KX8RX27BF3PMW8Z4J8E6RYX1	36	2026-01-01	2026-12-31	01KX8RX278M82TBT5HHQV14JX6	填写指引：金额单位为万元；到期前 90 天系统会自动预警到总览告警区，并通知负责人	f	01KX8RX27DS05NBRW5BX2MP72C	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	t
\.


--
-- Data for Name: cost_entry; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.cost_entry (project_id, entry_date, amount_10k, note, created_by, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
01KX8RX285QTZP8PMQ6DTCJ9KZ	2026-07-06	12.5	填写指引：成本按发生记流水（外包费/云资源/采购），执行率与 CPI 自动计算	\N	01KX8RX287RA2KXN2RZCJAD549	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	t
\.


--
-- Data for Name: department; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.department (code, name, parent_id, dept_type, external_source, external_id, sort, active, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
demo_it	【示例】信息技术部	\N	it	\N	\N	99	t	01KX8RX274X854TRCWQZTWC65E	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	f
\.


--
-- Data for Name: development_activity; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.development_activity (activity_type, topic, activity_date, host_id, participant_ids, output_link, remarks, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
\.


--
-- Data for Name: hiring_need; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.hiring_need (position_id, headcount, status, progress_note, id, created_at, updated_at, is_deleted, is_example, level, qualification) FROM stdin;
\.


--
-- Data for Name: idea; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.idea (idea_code, title, content, proposer, proposer_name, status, like_count, adopted_at, decline_reason, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
ID-DEMO-001	【示例】建议引入自动化巡检脚本减少手工检查	填写指引——建言内容建议包含：\n① 现状问题：每天早上人工检查 12 个系统状态，耗时约 40 分钟\n② 建议方案：用脚本定时巡检并推送异常告警\n③ 预期收益：每人每天节省 30 分钟，异常发现提前到分钟级\n提示：提出建言 +2 分；被点赞每次 +1 分；被管理员采纳 +20 分（分值可在积分规则中调整）	\N	系统示例	submitted	0	\N	\N	01KX8XERVZ90E76DCA1SH92535	2026-07-11 23:41:38.045139	2026-07-11 23:41:38.045139	f	t
\.


--
-- Data for Name: idea_like; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.idea_like (idea_id, voter, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
\.


--
-- Data for Name: in_app_notification; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.in_app_notification (recipient, title, content, link, read_at, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
\.


--
-- Data for Name: knowledge_article; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.knowledge_article (article_code, title, content, tags, status, author, author_name, view_count, helpful_count, linked_ticket_ids, source_requirement_id, id, created_at, updated_at, is_deleted, content_format, is_example) FROM stdin;
KB-DEMO-001	【示例】如何写一篇高质量的知识文章	# 如何写一篇高质量的知识文章\n\n> 本文是示例数据：正文用 Markdown 编写，本文结构即推荐模板。\n\n## 适用场景\n\n一句话说明什么情况下应参考本文（读者判断相关性的依据）。\n\n## 处理步骤\n\n1. 步骤要可执行、可复制（含命令/路径/截图链接）\n2. 每步写清预期结果\n3. 有风险的步骤标注注意事项\n\n## 验证方法\n\n写明如何确认问题已解决。\n\n## 常见坑\n\n- 记录踩过的坑，别人不再踩\n\n## 相关链接\n\n- 关联工单：在编辑页选择关联工单，读者可回看处理过程\n	["示例", "写作指引"]	published	\N	系统示例	0	0	[]	\N	01KX8RX28401BJHP09JA0ZK305	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	markdown	t
\.


--
-- Data for Name: knowledge_vote; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.knowledge_vote (article_id, person, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
\.


--
-- Data for Name: master_data; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.master_data (category, code, name, sort, active, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
business_line	internal_it	内部 IT	1	t	01KX3WBGWD7ZRTY4TA5DTJJJ8E	2026-07-10 00:46:10.659915	2026-07-10 00:46:10.659915	f	f
business_line	data_platform	数据平台	2	t	01KX3WBGWDRMWEE04MBPSBFSJ2	2026-07-10 00:46:10.659915	2026-07-10 00:46:10.659915	f	f
business_line	infra	基础设施	3	t	01KX3WBGWDEF42JK4NTPTQ8VK3	2026-07-10 00:46:10.659915	2026-07-10 00:46:10.659915	f	f
closure_code	resolved	已解决	1	t	01KX3WBGWDFRBP76VVAFTKHZDZ	2026-07-10 00:46:10.659915	2026-07-10 00:46:10.659915	f	f
closure_code	workaround	临时规避	2	t	01KX3WBGWDDGN9FAZ6BYBWMYHH	2026-07-10 00:46:10.659915	2026-07-10 00:46:10.659915	f	f
closure_code	not_reproducible	无法复现	3	t	01KX3WBGWDE51ACVJ51GGYZ1V2	2026-07-10 00:46:10.659915	2026-07-10 00:46:10.659915	f	f
closure_code	duplicate	重复单	4	t	01KX3WBGWDTTR73NRX5R9PJ4ZF	2026-07-10 00:46:10.659915	2026-07-10 00:46:10.659915	f	f
closure_code	cancelled	取消	5	t	01KX3WBGWDQHV65EPA8QC61502	2026-07-10 00:46:10.659915	2026-07-10 00:46:10.659915	f	f
requirement_source	biz_dept	业务部门	1	t	01KX3WBGWD94VMEYGFC9HGTCVP	2026-07-10 00:46:10.659915	2026-07-10 00:46:10.659915	f	f
requirement_source	management	管理层	2	t	01KX3WBGWD4MWKDC2J36HHGNRD	2026-07-10 00:46:10.659915	2026-07-10 00:46:10.659915	f	f
requirement_source	team_internal	团队内部	3	t	01KX3WBGWDQVDBNZGV27FGEPX5	2026-07-10 00:46:10.659915	2026-07-10 00:46:10.659915	f	f
requirement_source	idea_adopted	建言采纳	4	t	01KX3WBGWDVWG5RVS260RD5VQ1	2026-07-10 00:46:10.659915	2026-07-10 00:46:10.659915	f	f
ci_category	app	应用	1	t	01KX5KAZVFTEV5JRCC06F4PYE4	2026-07-10 16:47:05.061092	2026-07-10 16:47:05.061092	f	f
ci_category	server	服务器	2	t	01KX5KAZVFC1D0DJZTC16SC8MX	2026-07-10 16:47:05.061092	2026-07-10 16:47:05.061092	f	f
ci_category	cloud	云资源	3	t	01KX5KAZVFG224Q32JF15APFZZ	2026-07-10 16:47:05.061092	2026-07-10 16:47:05.061092	f	f
ci_category	network	网络	4	t	01KX5KAZVFFTPMWEPM57TWG3E5	2026-07-10 16:47:05.061092	2026-07-10 16:47:05.061092	f	f
ci_category	security	安全	5	t	01KX5KAZVFWHB4KF6KR0DYVW7P	2026-07-10 16:47:05.061092	2026-07-10 16:47:05.061092	f	f
ci_category	collab	协作	6	t	01KX5KAZVFYMCKHDSKVJT7205C	2026-07-10 16:47:05.061092	2026-07-10 16:47:05.061092	f	f
ci_category	euc	终端	7	t	01KX5KAZVFX1NJX1FY631T4D6X	2026-07-10 16:47:05.061092	2026-07-10 16:47:05.061092	f	f
ci_category	infra	基础设施	8	t	01KX5KAZVFY2N1PBZG15383E0F	2026-07-10 16:47:05.061092	2026-07-10 16:47:05.061092	f	f
ci_category	consulting	咨询服务	9	t	01KX5KAZVFC0JXPZ1VR0DDKA1D	2026-07-10 16:47:05.061092	2026-07-10 16:47:05.061092	f	f
sys_config	company_name	我的公司	1	t	01KX7VSMVGH6F3J9Z562YH9QQH	2026-07-11 13:53:22.793603	2026-07-11 13:53:22.793603	f	f
\.


--
-- Data for Name: milestone; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.milestone (project_id, name, target_date, description, achieved_at, overdue_warned, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
01KX8RX285QTZP8PMQ6DTCJ9KZ	【示例】一期上线	2026-08-20	填写指引：里程碑是关键节点（评审通过/上线/验收），逾期未达成会自动进入总览告警并通知项目经理	\N	f	01KX8RX287CMGSBDM0ANF9997M	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	t
\.


--
-- Data for Name: notification_outbox; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.notification_outbox (event_type, entity_type, entity_id, payload, channel, status, sent_at, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
\.


--
-- Data for Name: org_member; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.org_member (name, position_id, status, hire_date, email, feishu_user_id, skills, remarks, id, created_at, updated_at, is_deleted, name_en, department_id, mobile, external_source, external_id, employee_no, gender, birth_date, employment_type, supervisor_id, work_location, is_example) FROM stdin;
【示例】王小明	01KX8RX275FX04GVY8PZ0VS80C	在岗	2025-07-11	demo@example.com	\N	["Linux", "PostgreSQL"]	填写指引：这是示例人员，请将姓名/工号/部门等改为真实信息，或接入飞书同步后自动维护。技能标签用于岗位分工与流程派单参考	01KX8RX278M82TBT5HHQV14JX6	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	Wang Xiaoming	01KX8RX274X854TRCWQZTWC65E	13800000000	\N	\N	E0001	男	\N	正式	\N	上海	f
Test	01KX8RX275FX04GVY8PZ0VS80C	在岗	\N	\N	\N	[]	\N	01KXB2VAGH6567JSZV8A7W3GRF	2026-07-12 19:54:21.061304	2026-07-12 20:44:31.909439	t	ddd	01KX8RX274X854TRCWQZTWC65E	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
\.


--
-- Data for Name: perf_adjustment; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.perf_adjustment (period, person_id, kind, points, reason, created_by, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
2026-H2	01KX8RX278M82TBT5HHQV14JX6	bonus	5	验证用-重保特殊贡献	01KX3WBGWCAWHXV6BHVBCQM71Z	01KXB85CEC5DFF3YNA544ME9TR	2026-07-12 21:27:13.611785	2026-07-12 21:27:29.479378	t	f
\.


--
-- Data for Name: perf_override; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.perf_override (period, person_id, dimension_code, score, created_by, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
2026-H2	01KX8RX278M82TBT5HHQV14JX6	ticket_service	85	01KX3WBGWCAWHXV6BHVBCQM71Z	01KXB85CDWPQCPT8KPWYN7K40G	2026-07-12 21:27:13.594445	2026-07-12 21:27:29.462756	t	f
\.


--
-- Data for Name: perf_scheme; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.perf_scheme (name, description, position_ids, dimensions, is_default, active, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
默认方案（兜底）	填写指引：未被任何方案匹配到岗位的人员按此方案计分。建议保留一个均衡配置作为兜底。	[]	[{"code": "ticket_service", "weight": 20}, {"code": "change_compliance", "weight": 10}, {"code": "project_delivery", "weight": 15}, {"code": "requirement_delivery", "weight": 15}, {"code": "domain_satisfaction", "weight": 10}, {"code": "knowledge_contrib", "weight": 15}, {"code": "activity_points", "weight": 15}]	t	t	01KXB4NWWDZ3089VAHENG1K9ZV	2026-07-12 20:26:20.426823	2026-07-12 20:26:20.426823	f	f
运维序列（参考模板）	填写指引：运维岗位以服务工单 + 变更合规为主，少量项目/需求参与。已示例绑定【示例】运维工程师岗位，请改绑真实运维岗位并按贵司口径调整权重。	["01KX8RX275FX04GVY8PZ0VS80C"]	[{"code": "ticket_service", "weight": 40}, {"code": "change_compliance", "weight": 25}, {"code": "project_delivery", "weight": 10}, {"code": "requirement_delivery", "weight": 5}, {"code": "knowledge_contrib", "weight": 10}, {"code": "activity_points", "weight": 10}]	f	t	01KXB4NWWDXHYVSSG6P86TY76C	2026-07-12 20:26:20.426823	2026-07-12 20:26:20.426823	f	f
研发/产品序列（参考模板）	填写指引：产品经理与开发以需求/项目交付 + 所在业务域满意度为主。未绑定岗位前不生效，请在编辑中选择适用岗位（如产品经理/开发工程师）。	[]	[{"code": "requirement_delivery", "weight": 35}, {"code": "project_delivery", "weight": 25}, {"code": "domain_satisfaction", "weight": 15}, {"code": "knowledge_contrib", "weight": 10}, {"code": "activity_points", "weight": 15}]	f	t	01KXB4NWWD3BRVE1NZCBQ8KTX1	2026-07-12 20:26:20.426823	2026-07-12 20:26:20.426823	f	f
\.


--
-- Data for Name: point_entry; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.point_entry (person_id, points, source_type, source_ref, campaign_id, task_id, period, note, created_by, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
\.


--
-- Data for Name: point_rule; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.point_rule (code, name, points, active, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
idea_submit	提出建言	2	t	01KX8XERV99AQ4SR5W6JGG2WFH	2026-07-11 23:41:38.015794	2026-07-11 23:41:38.015794	f	f
idea_like	建言被点赞（每赞）	1	t	01KX8XERV9RJZEBMKYRZMEXDR6	2026-07-11 23:41:38.015794	2026-07-11 23:41:38.015794	f	f
idea_adopt	建言被采纳	20	t	01KX8XERV997NHHKY3V1T00TKY	2026-07-11 23:41:38.015794	2026-07-11 23:41:38.015794	f	f
ticket_resolved	工单解决	5	t	01KX8XERV9S4C2QG047YV01MX9	2026-07-11 23:41:38.015794	2026-07-11 23:41:38.015794	f	f
ticket_sla_met	工单 SLA 双达成	3	t	01KX8XERV95N4V9RJA8PPXVF33	2026-07-11 23:41:38.015794	2026-07-11 23:41:38.015794	f	f
ticket_satisfaction	满意度好评(≥4星)	5	t	01KX8XERV9T8DF6Z7S3P2RAC4X	2026-07-11 23:41:38.015794	2026-07-11 23:41:38.015794	f	f
wbs_done_on_time	项目任务按期完成	5	t	01KX8XERV9K67JTTD6GXKSSKD6	2026-07-11 23:41:38.015794	2026-07-11 23:41:38.015794	f	f
milestone_achieved	里程碑达成	10	t	01KX8XERV9FKNSY4QVDCPA5DG3	2026-07-11 23:41:38.015794	2026-07-11 23:41:38.015794	f	f
requirement_task_done	需求任务完成	5	t	01KX8XERV99BXZ3RP4JZSSYRTM	2026-07-11 23:41:38.015794	2026-07-11 23:41:38.015794	f	f
requirement_closed	需求关闭交付	10	t	01KX8XERV9VS6E741ACYD2RZTK	2026-07-11 23:41:38.015794	2026-07-11 23:41:38.015794	f	f
knowledge_published	发表知识文章	8	t	01KX8XERV939XFVDNY8CDKD4PW	2026-07-11 23:41:38.015794	2026-07-11 23:41:38.015794	f	f
knowledge_voted	知识被点有用（每次）	2	t	01KX8XERV97CTFZMCQGTYV8046	2026-07-11 23:41:38.015794	2026-07-11 23:41:38.015794	f	f
training_host	主讲/组织培训	15	t	01KX8XERV923YNWTMV5V461XB3	2026-07-11 23:41:38.015794	2026-07-11 23:41:38.015794	f	f
training_attend	参与培训	3	t	01KX8XERV9SGCNVRVZPRK1KFAM	2026-07-11 23:41:38.015794	2026-07-11 23:41:38.015794	f	f
\.


--
-- Data for Name: portfolio; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.portfolio (name, owner_id, year, description, sort, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
【示例】2026 数字化转型组合	01KX8RX278M82TBT5HHQV14JX6	2026	填写指引：组合是项目的战略分组（如按年度/按战略方向），项目创建时可挂到组合下统一查看	99	01KX8RX285M00TKYDTPX3E2XT6	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	t
\.


--
-- Data for Name: position; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public."position" (name, duties, headcount, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
【示例】运维工程师	填写指引：写清楚该岗位的分工职责边界，如：负责基础设施与应用运维、工单响应、变更实施	2	01KX8RX275FX04GVY8PZ0VS80C	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	f
\.


--
-- Data for Name: problem; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.problem (problem_code, title, description, priority, status, service_item_id, root_cause, workaround, owner, source_ticket_id, source_requirement_id, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
PB-DEMO-001	【示例】OA 高峰期频繁出现连接超时	填写指引：问题描述聚焦重复发生的现象与规律，如：每周一 9:00-10:00 高峰期出现，已有 3 张关联工单	P2	known_error	\N	填写指引：根因分析结论，如：连接池上限 100 低于高峰并发 150；转「已知错误」时必填	填写指引：临时规避方案，如：高峰期前预扩容连接池到 200，重启应用释放连接	01KX8RX278M82TBT5HHQV14JX6	01KX8RX27CZ9VPFYBTZXPPBT48	\N	01KX8RX283AMSQ0EAKX5BVHJFQ	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	t
\.


--
-- Data for Name: problem_ticket; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.problem_ticket (problem_id, ticket_id, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
01KX8RX283AMSQ0EAKX5BVHJFQ	01KX8RX27CZ9VPFYBTZXPPBT48	01KX8RX284SHN5Q6SM66VHJK0M	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	f
\.


--
-- Data for Name: process_definition; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.process_definition (code, name, entity_type, trigger_condition, version, active, description, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
incident_flow	事件处理流程	ticket	{"ticket_type": "incident"}	1	t	\N	01KX7H7HXYGHPQNPBWEVJ6RQVF	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
sr_flow	服务请求交付流程	ticket	{"ticket_type": "service_request"}	1	t	\N	01KX7H7HY1VG6BZE7HGKFN5540	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
change_flow	变更管理流程	ticket_change	{"ticket_type": "change"}	1	t	\N	01KX7H7HY2SWDDQ9WFJNGP3JVV	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
problem_flow	问题分析流程	problem	null	1	t	\N	01KX7H7HY3ZAYJRSEVQHVWPHH8	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
requirement_flow	需求交付流程	requirement	null	1	t	\N	01KX7H7HY30XVXBFWC6446XDFV	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
project_flow	项目关键节点流程	project	null	1	t	\N	01KX802B35T633K18FE4RPX2BC	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
\.


--
-- Data for Name: process_instance; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.process_instance (definition_id, entity_type, entity_id, status, current_step_seq, started_at, completed_at, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
01KX802B35T633K18FE4RPX2BC	project	01KX8T7D0NTWPGZ1WHDAGYB89J	进行中	1	2026-07-11 22:45:10.813347	\N	01KX8T7D0YNBXVSN10QCB8C7QY	2026-07-11 22:45:10.787016	2026-07-11 22:45:10.787016	f	f
\.


--
-- Data for Name: process_step; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.process_step (definition_id, seq, name, default_role, autonomy_level, sla_hours, description, id, created_at, updated_at, is_deleted, cc_roles, is_example) FROM stdin;
01KX7H7HXYGHPQNPBWEVJ6RQVF	1	受理定级	it_ops	L3	0.5	\N	01KX7H7HY120RGFS9936A9YBSM	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	[]	f
01KX7H7HXYGHPQNPBWEVJ6RQVF	2	诊断与处理	it_ops	L3	\N	\N	01KX7H7HY15SVAD5PHK0B58ZSP	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	[]	f
01KX7H7HXYGHPQNPBWEVJ6RQVF	3	解决与用户确认	it_ops	L3	\N	\N	01KX7H7HY1GK0P0N8SEYDRW02Z	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	[]	f
01KX7H7HXYGHPQNPBWEVJ6RQVF	4	关闭复盘	it_tm	L2	24	\N	01KX7H7HY17J0V9NK3TAM21JW7	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	[]	f
01KX7H7HY1VG6BZE7HGKFN5540	1	受理确认	it_ops	L2	4	\N	01KX7H7HY25NPT1J9SV4FZDH43	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	[]	f
01KX7H7HY1VG6BZE7HGKFN5540	2	实施交付	it_ops	L3	\N	\N	01KX7H7HY2TEHK2NK7Z85GFDVQ	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	[]	f
01KX7H7HY1VG6BZE7HGKFN5540	3	用户确认关闭	it_bp	L3	24	\N	01KX7H7HY26VEXKG8YQD8HWEQK	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	[]	f
01KX7H7HY3ZAYJRSEVQHVWPHH8	1	问题确认	it_ops	L3	24	\N	01KX7H7HY3K1ESWB1DBNFQ8920	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	[]	f
01KX7H7HY3ZAYJRSEVQHVWPHH8	2	根因分析	it_ops	L3	\N	\N	01KX7H7HY4510Z293XDTJ1EB4G	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	[]	f
01KX7H7HY3ZAYJRSEVQHVWPHH8	3	解决与验证	it_ops	L3	\N	\N	01KX7H7HY4A6XZ0EDX5MQ9QA1A	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	[]	f
01KX7H7HY3ZAYJRSEVQHVWPHH8	4	关闭复盘	it_tm	L2	48	\N	01KX7H7HY4XCGCKR14P1E1XCDP	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	[]	f
01KX7H7HY30XVXBFWC6446XDFV	1	需求登记与业务对齐	it_bp	L3	24	\N	01KX7H7HY5K82CPHRVSAK85ZVY	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	[]	f
01KX7H7HY30XVXBFWC6446XDFV	2	需求分析与方案	it_pdm	L3	\N	\N	01KX7H7HY5DXXME9D2K0DJ16Y1	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	[]	f
01KX7H7HY30XVXBFWC6446XDFV	3	排期与资源协调	it_bm	L3	48	\N	01KX7H7HY5PGG20DDQ7T125ZVW	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	[]	f
01KX7H7HY30XVXBFWC6446XDFV	4	开发实现	it_dev	L3	\N	\N	01KX7H7HY54Q7Y4HFYRGJ9JW72	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	[]	f
01KX7H7HY30XVXBFWC6446XDFV	5	验收与关闭	it_pdm	L3	\N	\N	01KX7H7HY5GQ221P0A1N330J15	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	[]	f
01KX7H7HY2SWDDQ9WFJNGP3JVV	1	变更登记与风险评估	is_mgr	L3	8	\N	01KX7H7HY35AE7ZC4XDNV0P0M7	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	["it_tm"]	f
01KX7H7HY2SWDDQ9WFJNGP3JVV	2	变更审批	cio	L3	24	\N	01KX7H7HY3ER8WPY2QRF5QADSB	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	["it_bm"]	f
01KX7H7HY2SWDDQ9WFJNGP3JVV	3	实施与验证	it_ops	L3	\N	\N	01KX7H7HY3E9JRJ4WTNZ42TT5M	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	["is_mgr", "it_bm"]	f
01KX7H7HY2SWDDQ9WFJNGP3JVV	4	变更复盘(PIR)	it_tm	L2	48	\N	01KX7H7HY3TJ1BJNHST4BCM5MV	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	["cio"]	f
01KX802B35T633K18FE4RPX2BC	1	立项启动	it_pm	L3	72	\N	01KX802B37B3S2629917QM073C	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	["cio", "it_bm"]	f
01KX802B35T633K18FE4RPX2BC	2	执行监控	it_pm	L3	\N	\N	01KX802B386CSTCG0APTXB3CYQ	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	[]	f
01KX802B35T633K18FE4RPX2BC	3	收尾复盘	it_pm	L2	72	\N	01KX802B38C6ZRWM55Z5ZKZKAF	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	["cio", "it_tm"]	f
\.


--
-- Data for Name: process_task; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.process_task (instance_id, step_id, assignee, status, started_at, due_at, completed_at, comment, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
01KX8T7D0YNBXVSN10QCB8C7QY	01KX802B37B3S2629917QM073C	01KX8RX278M82TBT5HHQV14JX6	待处理	2026-07-11 22:45:10.814681	2026-07-14 22:45:10.814681	\N	\N	01KX8T7D11C7VBS4TW47KXSD6W	2026-07-11 22:45:10.787016	2026-07-11 22:45:10.787016	f	f
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.project (project_code, name, pm, status, planned_start, planned_end, actual_start, actual_end, portfolio_id, service_item_id, budget_10k, description, latest_update, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
PJ-DEMO-001	【示例】数据中台建设项目	01KX8RX278M82TBT5HHQV14JX6	active	2026-06-21	2026-08-20	2026-06-21	\N	01KX8RX285M00TKYDTPX3E2XT6	01KX8RX27A9A93SDZS1MN29WXN	100	填写指引——项目描述建议包含：\n① 背景：为什么做（数据口径不一致，重复建设严重）\n② 目标：做成什么样（统一数仓与指标服务上线）\n③ 范围：边界在哪（一期覆盖销售与库存域，不含财务）\n提示：也可以用「章程导入」上传 .docx 自动生成项目+WBS+里程碑+风险	填写指引：最新动态一句话（本周完成数仓建模评审，下周开始 ETL 开发）——随时可改，让管理层扫一眼即知进展	01KX8RX285QTZP8PMQ6DTCJ9KZ	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	t
PJ-202607-0001	TEst	01KX8RX278M82TBT5HHQV14JX6	planning	2026-07-11	2026-07-26	\N	\N	01KX8RX285M00TKYDTPX3E2XT6	\N	50	\N	\N	01KX8T7D0NTWPGZ1WHDAGYB89J	2026-07-11 22:45:10.787016	2026-07-11 22:45:10.787016	f	f
\.


--
-- Data for Name: provision_rule; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.provision_rule (match_type, match_value, default_roles, sort, active, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
dept_type	business	["requester"]	10	t	01KX7AJ173CD6QWJVZAW6VJ7X2	2026-07-11 08:52:07.517523	2026-07-11 08:52:07.517523	f	f
dept_type	audit	["requester"]	20	t	01KX7AJ173G58V79GBNHZH7MSB	2026-07-11 08:52:07.517523	2026-07-11 08:52:07.517523	f	f
dept_type	it	["requester"]	30	t	01KX7AJ173M2EW92S7VTP1XMWB	2026-07-11 08:52:07.517523	2026-07-11 08:52:07.517523	f	f
\.


--
-- Data for Name: requirement; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.requirement (requirement_code, title, req_type, business_domain_id, description, source, requester, requester_name, moscow, owner, target_date, solution, acceptance_criteria, project_id, status, registered_at, analyzing_at, implementing_at, closed_at, closure_note, parent_requirement_id, remarks, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
RQ-DEMO-001	【示例】门店销售日报自动化	数据	01KX8RX279ZVVH658DZ9BEM0BX	填写指引——需求描述建议包含：\n① 现状与痛点：门店每天手工汇总 Excel，耗时 2 小时且易错\n② 期望：每天 9 点前自动生成日报推送\n③ 涉及范围：全国 120 家门店的销售与库存数据	业务部门	\N	【示例】业务用户	M	01KX8RX278M82TBT5HHQV14JX6	2026-08-10	填写指引：解决方案由产品经理在分析阶段填写，写方案要点与技术路线，如：基于数据中台指标服务生成报表，飞书机器人推送	[{"text": "填写指引：验收标准要可验证——报表口径与财务系统一致（误差为 0）", "checked": true}, {"text": "每日 9:00 前自动送达（连续 5 个工作日验证）", "checked": false}]	01KX8RX285QTZP8PMQ6DTCJ9KZ	implementing	2026-07-01 22:22:03.491802	2026-07-03 22:22:03.491802	2026-07-08 22:22:03.491802	\N	\N	\N	填写指引：验收标准未全部勾选时无法关闭；关闭时可一键转出遗留问题（进问题管理）与经验沉淀（进知识库）	01KX8RX289VCEG52MXQDCC0M57	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	t
\.


--
-- Data for Name: requirement_task; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.requirement_task (requirement_id, name, assignee, plan_date, status, done_at, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
01KX8RX289VCEG52MXQDCC0M57	【示例】指标口径确认	01KX8RX278M82TBT5HHQV14JX6	2026-07-10	已完成	2026-07-10 22:22:03.491802	01KX8RX2891FZ2FVJ9CEBP1Z5G	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	t
01KX8RX289VCEG52MXQDCC0M57	【示例】报表开发与推送配置	01KX8RX278M82TBT5HHQV14JX6	2026-07-21	进行中	\N	01KX8RX289QZ1ZA0TSMT3PSCNW	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	t
\.


--
-- Data for Name: risk; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.risk (project_id, title, probability, impact, mitigation, status, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
01KX8RX285QTZP8PMQ6DTCJ9KZ	【示例】关键数据源接口延期风险	中	高	填写指引：应对措施要具体可执行，如：提前两周与源系统团队确认接口规格，准备模拟数据兜底	开放	01KX8RX288RYWXE8S4253X84B4	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	t
\.


--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.role (code, name, description, base_role, is_builtin, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
admin	系统管理员	全部功能与系统配置	\N	t	01KX546DERF44RQ2M9JPB49Q3N	2026-07-10 12:22:26.512908	2026-07-10 12:22:26.512908	f	f
it_pdm	IT产品经理	侧重需求域：需求分析/排期/验收/关闭	\N	t	01KX546DERM3VXZDDTD2YKM6X5	2026-07-10 12:22:26.512908	2026-07-10 12:22:26.512908	f	f
it_pm	IT项目经理	侧重项目域：项目创建与管理	\N	t	01KX546DERRAP8AFY8MQTV9NF9	2026-07-10 12:22:26.512908	2026-07-10 12:22:26.512908	f	f
it_dev	IT开发	侧重交付：需求任务/WBS 任务/工单处理	\N	t	01KX546DER4DVVHJC4NPZ93KYX	2026-07-10 12:22:26.512908	2026-07-10 12:22:26.512908	f	f
it_ops	IT运维	侧重运维：工单/变更实施/问题/CMDB/SLA	\N	t	01KX546DERV90QKFN385RN0C0W	2026-07-10 12:22:26.512908	2026-07-10 12:22:26.512908	f	f
is_mgr	信息安全管理员	安全治理：安全工单/变更风险评估/审计查看	\N	t	01KX546DERRT3KRD99N81982T0	2026-07-10 12:22:26.512908	2026-07-10 12:22:26.512908	f	f
it_bp	IT业务合作伙伴	业务接口：需求登记与业务对齐/代提单	\N	t	01KX546DERK1YQGZSGM6AM0KG3	2026-07-10 12:22:26.512908	2026-07-10 12:22:26.512908	f	f
requester	业务用户	提交工单和需求、查询自己的单据、满意度评价	\N	t	01KX546DERX441MPE1XH9FQ0AD	2026-07-10 12:22:26.512908	2026-07-10 12:22:26.512908	f	f
auditor	审计员	全模块只读 + 审计日志查看，不可修改任何单据	\N	t	01KX7AJ173F3CF5G7BW02P1K2N	2026-07-11 08:52:07.517523	2026-07-11 08:52:07.517523	f	f
cio	CIO(IT总负责人)	IT 整体负责：全业务读写、审批、团队管理域	\N	t	01KX7EAA7EAY4CBVM27M8RARBE	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	IT业务线负责人	横向服务线：总体负责某业务域 IT 支持，对接需求/协调资源/过程管理（业务域负责人通常持此角色）	\N	t	01KX7EAA7E9P53VVZMXEMWZ670	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	IT专业线负责人	纵向专业线：资源池统一管理/资源配置/培训与技能提升（用户组负责人通常持此角色）	\N	t	01KX7EAA7E28PX96FWXV7G3GYP	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
\.


--
-- Data for Name: role_permission; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.role_permission (role_code, module, actions, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
requester	dashboard	["view"]	01KX7EAA7F9WK3GFKQSNS3B62R	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
requester	tickets	["view", "create"]	01KX7EAA7F2CK26CY4K2GNE92Y	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
requester	knowledge	["view"]	01KX7EAA7FK96BTVRJE45H6ZF5	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
requester	requirements	["view", "create"]	01KX7EAA7F5YDFNW9BN24ZTA0B	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	dashboard	["view"]	01KX7EAA7FBDR3GVS5E9D39242	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	tickets	["view"]	01KX7EAA7F83GZ7Z9DT2YP9TWK	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	catalog	["view"]	01KX7EAA7F2VWRRQAS34E27VSW	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	cmdb	["view"]	01KX7EAA7FNC60TEG06X2KCJ4M	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	sla	["view"]	01KX7EAA7FVQY82AW566ARBN9B	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	problems	["view"]	01KX7EAA7FTEA1TD86QZVRVVDJ	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	vendors	["view"]	01KX7EAA7FFE0F9RM9DR8P0EJT	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	contracts	["view"]	01KX7EAA7F1KCB0BXPF2HRSDPP	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	knowledge	["view"]	01KX7EAA7FW4GX0T6F6TVGDSN8	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	projects	["view"]	01KX7EAA7F49SBA6DT0W18H9MD	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	requirements	["view"]	01KX7EAA7F4YDTBC6NJCZX234B	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	team_overview	["view"]	01KX7EAA7F7JG0QYRRNY1J59WV	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	activities	["view"]	01KX7EAA7FQ3A27ZSM2EBRMQZ1	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	ideas	["view"]	01KX7EAA7FK7DCYTVSH8WYGBF2	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	charter	["view"]	01KX7EAA7FC9PS08ATX5T1A9P8	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	process_definitions	["view"]	01KX7EAA7FVYVX8QA0Q0WRP4H5	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	process_monitor	["view"]	01KX7EAA7FAZ2BQ26KTP62EMW6	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
auditor	admin_audit	["view"]	01KX7EAA7F5ZR7A388YZ88HGJ6	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_dev	dashboard	["view"]	01KX7EAA7FEHNZMG8NNKR6GP7W	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_dev	tickets	["view", "create", "edit"]	01KX7EAA7FTFNZ3H79TW2CQNWT	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_dev	catalog	["view"]	01KX7EAA7FBK8D1VQENQ5XXBD9	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_dev	cmdb	["view"]	01KX7EAA7F3CDGVRH1KTPH6PM1	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_dev	sla	["view"]	01KX7EAA7FD0H2B8DHJZDCAQ66	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_dev	problems	["view"]	01KX7EAA7F4HWD0ET9XQ6XCBXA	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_dev	vendors	["view"]	01KX7EAA7FJED2G9QB37XQJF2G	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_dev	contracts	["view"]	01KX7EAA7FGG05GP2MW5Y7DSE2	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_dev	knowledge	["view", "create", "edit"]	01KX7EAA7FSHJVQJZB7FQZAEMX	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_dev	projects	["view"]	01KX7EAA7FMW7NFMAN2SWYC31R	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_dev	requirements	["view", "create"]	01KX7EAA7FEA3NYQZWWHE349TY	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_dev	team_overview	["view"]	01KX7EAA7FZNHP4HR5AXM5FP33	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_dev	activities	["view", "create"]	01KX7EAA7F73MDWSN1F10MGMSX	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_dev	ideas	["view", "create"]	01KX7EAA7FCDZ6DHMM2VWWR0H2	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_dev	charter	["view"]	01KX7EAA7FEMAMYH483D8S95C1	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bp	dashboard	["view"]	01KX7EAA7FEXXYN252CJXCWBVG	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bp	tickets	["view", "create", "edit"]	01KX7EAA7FA83QDQGFQP8YAMW4	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bp	catalog	["view"]	01KX7EAA7FWC59JS3TZVR6CHC7	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bp	cmdb	["view"]	01KX7EAA7FEE3KK6CCCP5TP8G3	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bp	sla	["view"]	01KX7EAA7FZT955SJEM9E01YK5	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bp	problems	["view"]	01KX7EAA7FVRGZ8F8PSR2V0798	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bp	vendors	["view"]	01KX7EAA7FK39S4SXA1HBG4B38	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bp	contracts	["view"]	01KX7EAA7F55AKC74TBSXQM5K6	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bp	knowledge	["view", "create", "edit"]	01KX7EAA7FDW8WNAP33J0AK5QF	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bp	projects	["view"]	01KX7EAA7FPTEVBGJS2HC7XJ3W	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bp	requirements	["create", "edit", "view"]	01KX7EAA7FKN4K56Y9VEZ269T0	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bp	team_overview	["view"]	01KX7EAA7FA0KEHP1Z1RQBC53S	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bp	activities	["view", "create"]	01KX7EAA7FASE7J0SMP0FNYD3B	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bp	ideas	["view", "create"]	01KX7EAA7FYAAT4F5J0G8KP10A	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bp	charter	["view"]	01KX7EAA7F7TAZET11E5ZWRAEJ	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pdm	dashboard	["view"]	01KX7EAA7F4PK62NYQPKB7G8A4	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pdm	tickets	["view", "create", "edit"]	01KX7EAA7F0FZS00D5YCAMN1WT	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pdm	catalog	["view"]	01KX7EAA7FHKB1W1MR9G85VZ4T	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pdm	cmdb	["view"]	01KX7EAA7F38WM0FGB67A3FP61	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pdm	sla	["view"]	01KX7EAA7FPHRT88XX294RV1V2	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pdm	problems	["view"]	01KX7EAA7FP5NEZF6ATZMR0N9V	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pdm	vendors	["view"]	01KX7EAA7FJY0ABK10JX2KXM63	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pdm	contracts	["view"]	01KX7EAA7FAQAW3ZGPD6W2ZRG7	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pdm	knowledge	["view", "create", "edit"]	01KX7EAA7FAWG9TVH055NMP6FD	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pdm	projects	["view"]	01KX7EAA7FPS4CAYCRJRF2STDS	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pdm	requirements	["create", "edit", "view"]	01KX7EAA7FNCFYA7S4MYBNNTE5	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pdm	team_overview	["view"]	01KX7EAA7F42MPWDYN8M1C121J	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pdm	activities	["view", "create"]	01KX7EAA7F2XFVZ81Z43N8DAHR	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pdm	ideas	["view", "create"]	01KX7EAA7FA54P0V0GFGD7D5VK	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pdm	charter	["view"]	01KX7EAA7FKAV7GJQHK0T67HRF	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pm	dashboard	["view"]	01KX7EAA7F5C4209PF6VTQ1QJY	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pm	tickets	["view", "create", "edit"]	01KX7EAA7FFEP6M0APG7YYJX5Q	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pm	catalog	["view"]	01KX7EAA7FERKQ1F26A7F2H721	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pm	cmdb	["view"]	01KX7EAA7FZF86BRCTVEWH8EBR	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pm	sla	["view"]	01KX7EAA7FPBG3MNRY8GXHS3D5	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pm	problems	["view"]	01KX7EAA7FSKHPGGKFEMR901GG	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pm	vendors	["view"]	01KX7EAA7F30QD09HWNHAZY7M0	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pm	contracts	["view"]	01KX7EAA7F95W3EKRV9X9EJZ3C	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pm	knowledge	["view", "create", "edit"]	01KX7EAA7F9REMGGV0GBJ8QDE7	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pm	projects	["create", "edit", "view"]	01KX7EAA7FNH38K8K1VBN9F6ZT	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pm	requirements	["view", "create"]	01KX7EAA7FP8DPB4D4YGX67549	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pm	team_overview	["view"]	01KX7EAA7FGCCT5JNY04ZDK2ZV	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pm	activities	["view", "create"]	01KX7EAA7FGRVVA6TXBTM6BKTR	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pm	ideas	["view", "create"]	01KX7EAA7FV6R5K5E638GHF6SH	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_pm	charter	["view"]	01KX7EAA7F1BESN2SSCWHZ24NK	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_ops	dashboard	["view"]	01KX7EAA7FT8GSF07RGXDAE3Y7	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_ops	tickets	["view", "create", "edit"]	01KX7EAA7FG8MVA4EZ0TPEWH7Y	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_ops	catalog	["view"]	01KX7EAA7FFPW7V39EP5HED7TX	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_ops	cmdb	["create", "edit", "view"]	01KX7EAA7F6RZ7FAZJCXJ32AGD	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_ops	sla	["view"]	01KX7EAA7F0SE081SA5D8VW9YV	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_ops	problems	["create", "edit", "view"]	01KX7EAA7F6NYQATSW81C8EC3N	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_ops	vendors	["create", "edit", "view"]	01KX7EAA7FKA6RJ4Q93CN40MDP	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_ops	contracts	["create", "edit", "view"]	01KX7EAA7F753T6BSBAD36106X	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_ops	knowledge	["view", "create", "edit"]	01KX7EAA7F32VND8S0ZFTHXXTD	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_ops	projects	["view"]	01KX7EAA7F6V4EV8W50B8WZPSV	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_ops	requirements	["view", "create"]	01KX7EAA7F9MZDVSMCE6Y5PT39	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_ops	team_overview	["view"]	01KX7EAA7FN0ZBEXR29278W5S5	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_ops	activities	["view", "create"]	01KX7EAA7FD2XAMDMG4HB9Z83K	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_ops	ideas	["view", "create"]	01KX7EAA7FR2GA157F1162S7BP	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_ops	charter	["view"]	01KX7EAA7FKSCEYF7FV2VEQ6TT	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
is_mgr	dashboard	["view"]	01KX7EAA7FA9WP071XPBNW9SZM	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
is_mgr	tickets	["view", "create", "edit"]	01KX7EAA7F9AXRW3YVXQTH6C3J	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
is_mgr	catalog	["view"]	01KX7EAA7FVVPPTEM6MVV0JJDP	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
is_mgr	cmdb	["create", "edit", "view"]	01KX7EAA7F1MQ3HSD70CSKCB3J	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
is_mgr	sla	["view"]	01KX7EAA7FD5EM2MZASVY5H6BH	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
is_mgr	problems	["create", "edit", "view"]	01KX7EAA7F452DA0DQFJNF0K1Q	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
is_mgr	vendors	["view"]	01KX7EAA7FERM69RMGDWP8YVJT	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
is_mgr	contracts	["view"]	01KX7EAA7F0XAQRVP1KQJ2PESR	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
is_mgr	knowledge	["view", "create", "edit"]	01KX7EAA7FZ107JVYAHM2VW7CS	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
is_mgr	projects	["view"]	01KX7EAA7F5DPQXETXWXN6GBZ0	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
is_mgr	requirements	["view", "create"]	01KX7EAA7F8SZF136T46XDXR68	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
is_mgr	team_overview	["view"]	01KX7EAA7FJSZVPXZVTEHTQC6F	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
is_mgr	activities	["view", "create"]	01KX7EAA7FHNZR5841R61SFPWZ	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
is_mgr	ideas	["view", "create"]	01KX7EAA7F37D9KQJ95E13993P	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
is_mgr	charter	["view"]	01KX7EAA7F9AR8EHF2FPWRYGDG	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
is_mgr	admin_audit	["view"]	01KX7EAA7F60RMCV6CWQB1DQ02	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	dashboard	["view"]	01KX7EAA7FC2P9XFS31XT5DHD9	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	tickets	["view", "create", "edit"]	01KX7EAA7FX0SVPGFBRB3JDEQA	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	catalog	["view"]	01KX7EAA7FE7A77D21QB32PAHG	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	cmdb	["view"]	01KX7EAA7FFVSD0S8K656BPC3R	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	sla	["view"]	01KX7EAA7FXRJNM96B9S3AFHMD	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	problems	["view"]	01KX7EAA7FDHEAHJN9YD496XZW	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	vendors	["view"]	01KX7EAA7F7T6RNPE22C5CQ70Z	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	contracts	["view"]	01KX7EAA7FG73HK016T5ZPQAB3	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	knowledge	["view", "create", "edit"]	01KX7EAA7FM8EP8AC4BBX9G3RG	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	projects	["create", "edit", "view"]	01KX7EAA7FD1SXHAT2D15TRF30	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	requirements	["create", "edit", "view"]	01KX7EAA7F2F1R9PVF8FPNCW8J	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	team_overview	["view"]	01KX7EAA7FVES0VNEXDA3BATP2	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	activities	["view", "create"]	01KX7EAA7FVKHWKBS2G0GHM89N	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	ideas	["view", "create"]	01KX7EAA7FHMRHH8PST3DAC5RC	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	charter	["view"]	01KX7EAA7F7G334K6JFW5DDD2P	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	admin_business_domains	["view"]	01KX7EAA7FYZNQE58516B1XXDB	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_bm	process_monitor	["view"]	01KX7EAA7F0GYRNS63TYJ4MQWX	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	dashboard	["view"]	01KX7EAA7FK6X2S89DQRQBPYC1	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	tickets	["view", "create", "edit"]	01KX7EAA7F4G09ESAYEN4TVPDR	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	catalog	["view"]	01KX7EAA7FP12TPW60S8ZPVDR5	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	cmdb	["view"]	01KX7EAA7FN6APH45TBC2ES152	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	sla	["view"]	01KX7EAA7FB69ZJVQ8RS9XS26X	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	problems	["view"]	01KX7EAA7F3FPJ2J82WYNJAXHT	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	vendors	["view"]	01KX7EAA7FT66ASNXM0E9J47N7	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	contracts	["view"]	01KX7EAA7F545N8AYJ4VJ3PW04	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	knowledge	["view", "create", "edit"]	01KX7EAA7FBJ8RKZMJGPC3XSH1	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	projects	["view"]	01KX7EAA7FVZQP8WV202VFDT2S	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	requirements	["view", "create"]	01KX7EAA7FRX74H1M02VTV4VB7	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	team_overview	["view"]	01KX7EAA7F2YC26XZHJDEKWVEG	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	activities	["create", "edit", "view"]	01KX7EAA7FQWYCMFQVPXMXCTD0	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	charter	["edit", "view"]	01KX7EAA7FY9528ZJHPRBSEGQW	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	process_monitor	["view"]	01KX7EAA7FKW60X6ZR6C4XSC3Z	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	admin_members	["create", "edit", "view"]	01KX7EAA7FB5C1MH2XMASN9CAN	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
it_tm	ideas	["view", "create", "edit"]	01KX7EAA7F6H2KKK71TDJP9AZ3	2026-07-11 09:57:48.904417	2026-07-11 09:57:48.904417	f	f
cio	dashboard	["view", "create", "edit", "delete"]	01KXA15V535J9DRD2HH9YN4B80	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	tickets	["view", "create", "edit"]	01KXA15V53D0RB3EN341PK1VXA	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	catalog	["create", "edit", "view"]	01KXA15V534BEMPSAQMY5EZH9Z	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	cmdb	["create", "edit", "view"]	01KXA15V53H0713VB401239SBD	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	sla	["edit", "view"]	01KXA15V53EC4Y2CYB66CV6P67	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	problems	["create", "edit", "view"]	01KXA15V5394SJ0949406VEHJK	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	vendors	["create", "edit", "view"]	01KXA15V53A1WJ015AR8G1RF92	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	contracts	["create", "edit", "view"]	01KXA15V53VSYH5SNSP6ZF5T2S	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	knowledge	["view", "create", "edit"]	01KXA15V53D6DM18BX9NHNFGQ6	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	projects	["create", "edit", "view"]	01KXA15V53WETX2JD4H57XGFYR	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	requirements	["create", "edit", "view"]	01KXA15V53NMKVHT0MFNTC7RG2	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	process_definitions	["view"]	01KXA15V53WCW16DDZQT2FEGVD	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	process_monitor	["view"]	01KXA15V53B16V0P2ZXCR2XJVA	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	team_overview	["view"]	01KXA15V53K5V0PVK2N9MEZ01Y	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	activities	["create", "edit", "view"]	01KXA15V53NFQ3325TB454TWQN	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	ideas	["create", "edit", "view"]	01KXA15V538RS4CZRR40NX1PH1	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	charter	["edit", "view"]	01KXA15V53SQYBY8Q7N0MJAJAF	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	admin_users	["view", "create", "edit", "delete"]	01KXA15V53MPGBSBWBHYNZZQBC	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	admin_roles	["view", "create", "edit", "delete"]	01KXA15V5313F76B89FSXZ202N	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	admin_groups	["view", "create", "edit", "delete"]	01KXA15V53TNHYZT5SDDS5YDKS	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	admin_permissions	["view", "create", "edit", "delete"]	01KXA15V531REN7GQXH3GJME1Y	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	admin_provision	["view", "create", "edit", "delete"]	01KXA15V53RQVA1KQB6ZGYMJN9	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	admin_departments	["view", "create", "edit", "delete"]	01KXA15V53Y9JS4HEQQTXN7QDJ	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	admin_business_domains	["create", "edit", "view"]	01KXA15V53H6T82ZDQPF1C26AB	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	admin_master_data	["view", "create", "edit", "delete"]	01KXA15V53RXA6RF6S4VESEGSA	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	admin_workflow	["view", "create", "edit", "delete"]	01KXA15V53KJDTBYQQQNEEH6TE	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	admin_audit	["view"]	01KXA15V530A03B4Z6W8JY80CY	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	performance	["view", "create", "edit"]	01KXA15V53NA0EVVBNJ28WN4RD	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	positions	["view", "create", "edit"]	01KXA15V53MQYV3KB1RVYTSJNA	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
cio	admin_members	["view", "create", "edit", "delete"]	01KXA15V53GZ4ZRGA5XBPH2AXS	2026-07-12 10:05:54.195282	2026-07-12 10:05:54.195282	f	f
it_bm	performance	["view", "create", "edit"]	08e62e943a429ab9eedf7a7a7a	2026-07-12 21:25:40.847483	2026-07-12 21:25:40.847483	f	f
it_tm	performance	["view", "create", "edit"]	3675a40dc14accae0d2bf91204	2026-07-12 21:25:40.847483	2026-07-12 21:25:40.847483	f	f
\.


--
-- Data for Name: service_catalog; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.service_catalog (code, name, tier, description, sort, status, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
SC-INIT-0001	通用 IT 服务	silver	初始目录，可编辑	1	上架	01KX7H7HY548VADZRSX1PGJFPS	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
SC-DEMO	【示例】基础 IT 服务	gold	填写指引：目录是服务的分类（如基础设施/应用系统/办公支持），分级 gold/silver/bronze 代表服务重要性	0	上架	01KX8RX279VCGDENHVY1HNH3B2	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	t
\.


--
-- Data for Name: service_item; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.service_item (item_code, name, catalog_id, service_type, owner, description, sla_response_hours, sla_resolution_hours, target_audience, status, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
SI-INIT-0001	通用支持服务	01KX7H7HY548VADZRSX1PGJFPS	日常运维	\N	未细分服务项前的默认入口，可编辑	\N	\N	\N	上架	01KX7H7HY5R9G9FHXYS2DW7V1A	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
SI-DEMO	【示例】数据库支持服务	01KX8RX279VCGDENHVY1HNH3B2	日常运维	01KX8RX278M82TBT5HHQV14JX6	填写指引：说清服务内容与边界，如：PostgreSQL/MySQL 的安装、调优、备份恢复与故障处置	\N	\N	填写指引：写服务对象，如全体员工/仅研发部门；SLA 两栏留空=使用全局策略，特殊承诺才填	上架	01KX8RX27A9A93SDZS1MN29WXN	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	t
\.


--
-- Data for Name: sla_policy; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.sla_policy (priority, response_minutes, resolution_hours, active, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
P1	30	4	t	01KX3Z1HZFY7FEPJNC95KH1AHQ	2026-07-10 01:33:09.991471	2026-07-10 01:33:09.991471	f	f
P2	60	8	t	01KX3Z1HZFS03XZ6MDZ4C2TGGR	2026-07-10 01:33:09.991471	2026-07-10 01:33:09.991471	f	f
P3	240	24	t	01KX3Z1HZFV6KZJQ03A4FDDRNX	2026-07-10 01:33:09.991471	2026-07-10 01:33:09.991471	f	f
P4	480	72	t	01KX3Z1HZF97FZM365KEFDWQNT	2026-07-10 01:33:09.991471	2026-07-10 01:33:09.991471	f	f
\.


--
-- Data for Name: team_charter; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.team_charter (vision, goals, principles, updated_by, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
\.


--
-- Data for Name: ticket; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.ticket (ticket_code, title, ticket_type, priority, description, service_item_id, assignee, ci_id, remarks, change_type, risk_level, change_reason, rollback_plan, planned_start_at, planned_end_at, implementation_plan, solution, root_cause, closure_code, satisfaction, approved_by, approved_at, approval_comment, status, submitter, submitter_name, submitter_dept, service_line, submitted_at, first_response_at, resolved_at, closed_at, paused_minutes, paused_started_at, reopen_count, first_time_fix, sla_response_min, sla_resolution_hours, actual_response_min, actual_resolution_hours, sla_response_met, sla_resolution_met, sla_warned, problem_id, requirement_id, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
TK-DEMO-001	【示例】OA 系统无法登录	incident	P2	填写指引——描述请包含四要素：\n① 现象：打开 OA 提示 504 网关超时\n② 影响范围：行政部约 30 人无法办公\n③ 已尝试：清缓存、换浏览器均无效\n④ 期望：尽快恢复访问	01KX8RX27A9A93SDZS1MN29WXN	01KX8RX278M82TBT5HHQV14JX6	\N	填写指引：备注可补充截图链接、方便联系的时段等	\N	\N	\N	\N	\N	\N	\N	填写指引：解决方案写处置动作+验证结果，如：重启应用池并扩容连接数，请用户复测确认恢复	填写指引：根因写技术层面的真正原因，如：连接池耗尽；若为重复性问题请点「升级为问题」	\N	\N	\N	\N	\N	resolved	\N	【示例】业务用户	行政部	【示例】基础 IT 服务	2026-07-11 16:22:03.491802	2026-07-11 16:37:03.491802	2026-07-11 20:22:03.491802	\N	0	\N	0	t	60	8	15	4	t	t	f	\N	\N	01KX8RX27CZ9VPFYBTZXPPBT48	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	t
TK-DEMO-002	【示例】生产数据库版本升级	change	P2	填写指引：变更描述写清楚变更对象、内容与业务影响窗口	01KX8RX27A9A93SDZS1MN29WXN	01KX8RX278M82TBT5HHQV14JX6	\N	\N	普通	中	填写指引：变更原因写驱动因素，如：官方版本停止安全更新，需升级至受支持版本	填写指引：回退方案必填且要可执行，如：保留旧版本容器镜像与全量备份，30 分钟内可回切	2026-07-13 22:22:03.491802	2026-07-14 02:22:03.491802	填写指引：实施方案写步骤与验证点，如：①停应用→②备份→③升级→④业务验证清单	\N	\N	\N	\N	\N	2026-07-11 19:22:03.491802	填写指引：审批意见写批准条件，如：同意在周六窗口执行，实施前完成备份并通知业务方	approved	\N	【示例】王小明	\N	【示例】基础 IT 服务	2026-07-10 22:22:03.491802	2026-07-11 02:22:03.491802	\N	\N	0	\N	0	\N	60	8	30	\N	t	\N	t	\N	\N	01KX8RX282QZMMH3M4QQESCBM0	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.533161	f	t
\.


--
-- Data for Name: user_group; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.user_group (code, name, description, id, created_at, updated_at, is_deleted, roles, owner_id, is_example) FROM stdin;
\.


--
-- Data for Name: user_group_member; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.user_group_member (group_id, person_id, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
\.


--
-- Data for Name: vendor; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.vendor (code, name, contact, phone, email, service_scope, rating, status, remarks, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
VD-DEMO	【示例】华信云科技有限公司	张经理（填写指引：写对接人姓名+称谓）	021-88886666	support@example.com	填写指引：写清楚该供应商提供的服务范围，如：云资源、数据库维保、驻场支持	A	合作中	填写指引：评级 A-D 由年度评估得出；备注可记录合作历史与注意事项	01KX8RX27BF3PMW8Z4J8E6RYX1	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	t
\.


--
-- Data for Name: wbs_task; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.wbs_task (project_id, parent_task_id, wbs_code, name, assignee, start_date, end_date, status, completed_at, description, deliverable, predecessor_ids, sort, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
01KX8RX285QTZP8PMQ6DTCJ9KZ	\N	1	【示例】需求调研与建模	01KX8RX278M82TBT5HHQV14JX6	2026-06-21	2026-07-03	已完成	2026-07-03 22:22:03.491802	填写指引：任务说明写工作内容要点；负责人完成后自己把状态改为已完成，项目进度自动联动	填写指引：交付物写可检查的产出，如：调研纪要+数据模型设计文档	[]	0	01KX8RX286R8J32K6YCC7AY2E0	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	t
01KX8RX285QTZP8PMQ6DTCJ9KZ	\N	2	【示例】平台搭建与 ETL 开发	01KX8RX278M82TBT5HHQV14JX6	2026-07-04	2026-07-31	进行中	\N	填写指引：本任务设置了前置任务（需求调研），甘特图上会显示虚线依赖箭头	可用的数仓环境与首批 ETL 作业	["01KX8RX286R8J32K6YCC7AY2E0"]	1	01KX8RX2888A7PEFMX8SHY3B6V	2026-07-11 22:22:03.491518	2026-07-11 22:22:03.491518	f	t
\.


--
-- Data for Name: workflow_status; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.workflow_status (entity_type, code, name, is_initial, is_terminal, sort, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
problem	new	新建	t	f	1	01KX7H7HXZS2RQAY3YSPZDRA9F	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
problem	analyzing	分析中	f	f	2	01KX7H7HXZ2GZ019HP0Q9R6E1F	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
problem	known_error	已知错误	f	f	3	01KX7H7HXZJMVVHSQ7ZFV3PW37	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
problem	resolved	已解决	f	f	4	01KX7H7HXZGQSG5NVYJKS73X1S	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
problem	closed	已关闭	f	t	5	01KX7H7HXZ5XB5QD45AW5HS1A4	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket	new	新建	t	f	1	01KX7H7HXZ5VNHTA9CY7V1QE4H	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket	processing	处理中	f	f	2	01KX7H7HXZAQEGMWZHWSTHJQWE	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket	paused	挂起	f	f	3	01KX7H7HXZT8QEV30T579891DX	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket	resolved	已解决	f	f	4	01KX7H7HXZS91D75G96K7MMCDY	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket	closed	已关闭	f	t	5	01KX7H7HXZFSEFJKDCXGQGJ5KN	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket_change	new	新建	t	f	1	01KX7H7HXZYQMRZYCT13M8ZRMN	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket_change	pending_approval	待审批	f	f	2	01KX7H7HXZJAAY7MMWYYTZQW1N	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket_change	approved	已批准	f	f	3	01KX7H7HXZCHK5TSDK9KKTZPR5	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket_change	rejected	已拒绝	f	t	4	01KX7H7HXZJJJ4SH0WX25JQQCG	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket_change	implementing	实施中	f	f	5	01KX7H7HXZVVEYVGF1B6KC137Y	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket_change	rolled_back	已回退	f	f	6	01KX7H7HXZ0ERJRK44HA7NSCXZ	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket_change	resolved	已解决	f	f	7	01KX7H7HXZTTDN29KK107NZZGX	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket_change	closed	已关闭	f	t	8	01KX7H7HXZVEXJX5DTQJ8NTW80	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
project	planning	规划中	t	f	1	01KX802B35XNXJ223SKK7E23PA	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
project	active	进行中	f	f	2	01KX802B35F2PPMSF3DTZJZNG7	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
project	paused	已暂停	f	f	3	01KX802B35RSKHS2P1MR1H86DK	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
project	completed	已完成	f	f	4	01KX802B35QMV4B2QETDN5BDDX	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
project	closed	已关闭	f	t	5	01KX802B35BJ95S9ZC1ANFJSNW	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
project	cancelled	已取消	f	t	6	01KX802B35T64VGEXWVG3WJDZ5	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
requirement	registered	已登记	t	f	1	01KX802B350CRNABFSZFCMVGDG	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
requirement	analyzing	分析中	f	f	2	01KX802B35A9T3XQATCEEQ7RPJ	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
requirement	implementing	实现中	f	f	3	01KX802B35S2XT9H372NPAATG5	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
requirement	closed	已关闭	f	t	4	01KX802B35SAV536VWAA0ZTV28	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
requirement	on_hold	已搁置	f	f	5	01KX802B35SKRR8361P6QPMP98	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
requirement	cancelled	已取消	f	t	6	01KX802B35AF7J85WDQAAMW7Z9	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
\.


--
-- Data for Name: workflow_transition; Type: TABLE DATA; Schema: public; Owner: aom
--

COPY public.workflow_transition (entity_type, from_code, to_code, allowed_roles, id, created_at, updated_at, is_deleted, is_example) FROM stdin;
problem	new	analyzing	[]	01KX7H7HY0GXXQJXBCX2FC4RNC	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
problem	analyzing	known_error	[]	01KX7H7HY0SDA6K96V00MWDYD8	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
problem	known_error	resolved	[]	01KX7H7HY0SWM12ADQP2WEJXA0	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
problem	analyzing	resolved	[]	01KX7H7HY0RBEYZNFQ1Q3AX16M	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
problem	resolved	closed	[]	01KX7H7HY08SR7QMFZ4ZERP48V	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
problem	resolved	analyzing	[]	01KX7H7HY0M173NRWDSWXX07H6	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket	new	processing	[]	01KX7H7HY0PEE3YFEJ8N0QTWK7	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket	new	resolved	[]	01KX7H7HY0H8W80RNR0VAAD8N5	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket	processing	paused	[]	01KX7H7HY0170P6BQ1DK4ZB8TE	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket	paused	processing	[]	01KX7H7HY0EFW9GYHQXS5KQ642	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket	processing	resolved	[]	01KX7H7HY0JV5BEEA4ZN9RTJW2	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket	resolved	processing	[]	01KX7H7HY0QDC4B2PAHHVJBC2P	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket	resolved	closed	[]	01KX7H7HY0HK969KF11N5S753E	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket_change	new	pending_approval	[]	01KX7H7HY0CFT58DV0A1ZSA0AM	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket_change	pending_approval	approved	["cio", "it_tm"]	01KX7H7HY0XH6NHJ2K63MV2J62	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket_change	pending_approval	rejected	["cio", "it_tm"]	01KX7H7HY0KR1X1QRBV07GHQ3X	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket_change	approved	implementing	[]	01KX7H7HY0ZS9SGP1BR7GNWAVV	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket_change	implementing	resolved	[]	01KX7H7HY0TN0NT7C64Z37H66J	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket_change	implementing	rolled_back	[]	01KX7H7HY0S7QHE287ZBKKEFS5	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket_change	rolled_back	closed	[]	01KX7H7HY086DF1HT17RMBGFAY	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
ticket_change	resolved	closed	[]	01KX7H7HY0XZP78E1720Z1AGFX	2026-07-11 10:48:44.213317	2026-07-11 10:48:44.213317	f	f
project	planning	active	[]	01KX802B36CKHDRP8GGTV2Q66D	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
project	active	paused	[]	01KX802B362GE02F7R0CY3KZMZ	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
project	paused	active	[]	01KX802B36WABVE0JX19AZ9C82	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
project	active	completed	[]	01KX802B368Y4F9ECNG9BP5YTG	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
project	completed	closed	[]	01KX802B364H6VX090DH7JS7JY	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
project	planning	cancelled	[]	01KX802B36PVPXK5P0PC32QJPD	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
project	active	cancelled	[]	01KX802B3677C98DED4MFYS7EQ	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
requirement	registered	analyzing	[]	01KX802B36P5033BXP7HBBJJC9	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
requirement	analyzing	implementing	[]	01KX802B36GYKMTKDAJKDCTGHN	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
requirement	implementing	closed	[]	01KX802B36Z5G8DMV9C0H19F6C	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
requirement	registered	on_hold	[]	01KX802B36V7WJJ6MGM9WB6R0F	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
requirement	analyzing	on_hold	[]	01KX802B36T8BR6PZDZXHT1WA9	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
requirement	implementing	on_hold	[]	01KX802B36J0KT9GAEB95F5EB8	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
requirement	on_hold	analyzing	[]	01KX802B36DBQC5E4W23F1H062	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
requirement	registered	cancelled	[]	01KX802B36DK574ZMP9QTH4BQS	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
requirement	analyzing	cancelled	[]	01KX802B364SDHHEY3KHYJ94P0	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
requirement	on_hold	cancelled	[]	01KX802B3635H6N7JJ10QZ5388	2026-07-11 15:08:02.007609	2026-07-11 15:08:02.007609	f	f
\.


--
-- Name: activity_campaign activity_campaign_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.activity_campaign
    ADD CONSTRAINT activity_campaign_pkey PRIMARY KEY (id);


--
-- Name: attachment attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.attachment
    ADD CONSTRAINT attachment_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: business_domain business_domain_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.business_domain
    ADD CONSTRAINT business_domain_code_key UNIQUE (code);


--
-- Name: business_domain_member business_domain_member_domain_id_person_id_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.business_domain_member
    ADD CONSTRAINT business_domain_member_domain_id_person_id_key UNIQUE (domain_id, person_id);


--
-- Name: business_domain_member business_domain_member_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.business_domain_member
    ADD CONSTRAINT business_domain_member_pkey PRIMARY KEY (id);


--
-- Name: business_domain business_domain_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.business_domain
    ADD CONSTRAINT business_domain_pkey PRIMARY KEY (id);


--
-- Name: campaign_task campaign_task_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.campaign_task
    ADD CONSTRAINT campaign_task_pkey PRIMARY KEY (id);


--
-- Name: ci ci_ci_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.ci
    ADD CONSTRAINT ci_ci_code_key UNIQUE (ci_code);


--
-- Name: ci ci_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.ci
    ADD CONSTRAINT ci_pkey PRIMARY KEY (id);


--
-- Name: ci_relationship ci_relationship_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.ci_relationship
    ADD CONSTRAINT ci_relationship_pkey PRIMARY KEY (id);


--
-- Name: ci_relationship ci_relationship_source_ci_id_target_ci_id_relation_type_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.ci_relationship
    ADD CONSTRAINT ci_relationship_source_ci_id_target_ci_id_relation_type_key UNIQUE (source_ci_id, target_ci_id, relation_type);


--
-- Name: contract contract_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT contract_code_key UNIQUE (code);


--
-- Name: contract contract_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT contract_pkey PRIMARY KEY (id);


--
-- Name: cost_entry cost_entry_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.cost_entry
    ADD CONSTRAINT cost_entry_pkey PRIMARY KEY (id);


--
-- Name: department department_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.department
    ADD CONSTRAINT department_code_key UNIQUE (code);


--
-- Name: department department_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.department
    ADD CONSTRAINT department_pkey PRIMARY KEY (id);


--
-- Name: development_activity development_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.development_activity
    ADD CONSTRAINT development_activity_pkey PRIMARY KEY (id);


--
-- Name: hiring_need hiring_need_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.hiring_need
    ADD CONSTRAINT hiring_need_pkey PRIMARY KEY (id);


--
-- Name: idea idea_idea_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.idea
    ADD CONSTRAINT idea_idea_code_key UNIQUE (idea_code);


--
-- Name: idea_like idea_like_idea_id_voter_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.idea_like
    ADD CONSTRAINT idea_like_idea_id_voter_key UNIQUE (idea_id, voter);


--
-- Name: idea_like idea_like_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.idea_like
    ADD CONSTRAINT idea_like_pkey PRIMARY KEY (id);


--
-- Name: idea idea_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.idea
    ADD CONSTRAINT idea_pkey PRIMARY KEY (id);


--
-- Name: in_app_notification in_app_notification_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.in_app_notification
    ADD CONSTRAINT in_app_notification_pkey PRIMARY KEY (id);


--
-- Name: knowledge_article knowledge_article_article_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.knowledge_article
    ADD CONSTRAINT knowledge_article_article_code_key UNIQUE (article_code);


--
-- Name: knowledge_article knowledge_article_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.knowledge_article
    ADD CONSTRAINT knowledge_article_pkey PRIMARY KEY (id);


--
-- Name: knowledge_vote knowledge_vote_article_id_person_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.knowledge_vote
    ADD CONSTRAINT knowledge_vote_article_id_person_key UNIQUE (article_id, person);


--
-- Name: knowledge_vote knowledge_vote_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.knowledge_vote
    ADD CONSTRAINT knowledge_vote_pkey PRIMARY KEY (id);


--
-- Name: master_data master_data_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.master_data
    ADD CONSTRAINT master_data_pkey PRIMARY KEY (id);


--
-- Name: milestone milestone_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.milestone
    ADD CONSTRAINT milestone_pkey PRIMARY KEY (id);


--
-- Name: notification_outbox notification_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.notification_outbox
    ADD CONSTRAINT notification_outbox_pkey PRIMARY KEY (id);


--
-- Name: org_member org_member_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.org_member
    ADD CONSTRAINT org_member_pkey PRIMARY KEY (id);


--
-- Name: perf_adjustment perf_adjustment_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.perf_adjustment
    ADD CONSTRAINT perf_adjustment_pkey PRIMARY KEY (id);


--
-- Name: perf_override perf_override_period_person_id_dimension_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.perf_override
    ADD CONSTRAINT perf_override_period_person_id_dimension_code_key UNIQUE (period, person_id, dimension_code);


--
-- Name: perf_override perf_override_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.perf_override
    ADD CONSTRAINT perf_override_pkey PRIMARY KEY (id);


--
-- Name: perf_scheme perf_scheme_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.perf_scheme
    ADD CONSTRAINT perf_scheme_pkey PRIMARY KEY (id);


--
-- Name: point_entry point_entry_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.point_entry
    ADD CONSTRAINT point_entry_pkey PRIMARY KEY (id);


--
-- Name: point_rule point_rule_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.point_rule
    ADD CONSTRAINT point_rule_code_key UNIQUE (code);


--
-- Name: point_rule point_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.point_rule
    ADD CONSTRAINT point_rule_pkey PRIMARY KEY (id);


--
-- Name: portfolio portfolio_name_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.portfolio
    ADD CONSTRAINT portfolio_name_key UNIQUE (name);


--
-- Name: portfolio portfolio_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.portfolio
    ADD CONSTRAINT portfolio_pkey PRIMARY KEY (id);


--
-- Name: position position_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public."position"
    ADD CONSTRAINT position_pkey PRIMARY KEY (id);


--
-- Name: problem problem_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.problem
    ADD CONSTRAINT problem_pkey PRIMARY KEY (id);


--
-- Name: problem problem_problem_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.problem
    ADD CONSTRAINT problem_problem_code_key UNIQUE (problem_code);


--
-- Name: problem_ticket problem_ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.problem_ticket
    ADD CONSTRAINT problem_ticket_pkey PRIMARY KEY (id);


--
-- Name: problem_ticket problem_ticket_problem_id_ticket_id_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.problem_ticket
    ADD CONSTRAINT problem_ticket_problem_id_ticket_id_key UNIQUE (problem_id, ticket_id);


--
-- Name: process_definition process_definition_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.process_definition
    ADD CONSTRAINT process_definition_code_key UNIQUE (code);


--
-- Name: process_definition process_definition_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.process_definition
    ADD CONSTRAINT process_definition_pkey PRIMARY KEY (id);


--
-- Name: process_instance process_instance_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.process_instance
    ADD CONSTRAINT process_instance_pkey PRIMARY KEY (id);


--
-- Name: process_step process_step_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.process_step
    ADD CONSTRAINT process_step_pkey PRIMARY KEY (id);


--
-- Name: process_task process_task_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.process_task
    ADD CONSTRAINT process_task_pkey PRIMARY KEY (id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: project project_project_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_project_code_key UNIQUE (project_code);


--
-- Name: provision_rule provision_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.provision_rule
    ADD CONSTRAINT provision_rule_pkey PRIMARY KEY (id);


--
-- Name: requirement requirement_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.requirement
    ADD CONSTRAINT requirement_pkey PRIMARY KEY (id);


--
-- Name: requirement requirement_requirement_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.requirement
    ADD CONSTRAINT requirement_requirement_code_key UNIQUE (requirement_code);


--
-- Name: requirement_task requirement_task_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.requirement_task
    ADD CONSTRAINT requirement_task_pkey PRIMARY KEY (id);


--
-- Name: risk risk_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.risk
    ADD CONSTRAINT risk_pkey PRIMARY KEY (id);


--
-- Name: role role_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_code_key UNIQUE (code);


--
-- Name: role_permission role_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT role_permission_pkey PRIMARY KEY (id);


--
-- Name: role_permission role_permission_role_code_module_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT role_permission_role_code_module_key UNIQUE (role_code, module);


--
-- Name: role role_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id);


--
-- Name: service_catalog service_catalog_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.service_catalog
    ADD CONSTRAINT service_catalog_code_key UNIQUE (code);


--
-- Name: service_catalog service_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.service_catalog
    ADD CONSTRAINT service_catalog_pkey PRIMARY KEY (id);


--
-- Name: service_item service_item_item_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.service_item
    ADD CONSTRAINT service_item_item_code_key UNIQUE (item_code);


--
-- Name: service_item service_item_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.service_item
    ADD CONSTRAINT service_item_pkey PRIMARY KEY (id);


--
-- Name: sla_policy sla_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.sla_policy
    ADD CONSTRAINT sla_policy_pkey PRIMARY KEY (id);


--
-- Name: sla_policy sla_policy_priority_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.sla_policy
    ADD CONSTRAINT sla_policy_priority_key UNIQUE (priority);


--
-- Name: team_charter team_charter_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.team_charter
    ADD CONSTRAINT team_charter_pkey PRIMARY KEY (id);


--
-- Name: ticket ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.ticket
    ADD CONSTRAINT ticket_pkey PRIMARY KEY (id);


--
-- Name: ticket ticket_ticket_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.ticket
    ADD CONSTRAINT ticket_ticket_code_key UNIQUE (ticket_code);


--
-- Name: user_group user_group_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_code_key UNIQUE (code);


--
-- Name: user_group_member user_group_member_group_id_person_id_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.user_group_member
    ADD CONSTRAINT user_group_member_group_id_person_id_key UNIQUE (group_id, person_id);


--
-- Name: user_group_member user_group_member_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.user_group_member
    ADD CONSTRAINT user_group_member_pkey PRIMARY KEY (id);


--
-- Name: user_group user_group_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_pkey PRIMARY KEY (id);


--
-- Name: vendor vendor_code_key; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.vendor
    ADD CONSTRAINT vendor_code_key UNIQUE (code);


--
-- Name: vendor vendor_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.vendor
    ADD CONSTRAINT vendor_pkey PRIMARY KEY (id);


--
-- Name: wbs_task wbs_task_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.wbs_task
    ADD CONSTRAINT wbs_task_pkey PRIMARY KEY (id);


--
-- Name: workflow_status workflow_status_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.workflow_status
    ADD CONSTRAINT workflow_status_pkey PRIMARY KEY (id);


--
-- Name: workflow_transition workflow_transition_pkey; Type: CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.workflow_transition
    ADD CONSTRAINT workflow_transition_pkey PRIMARY KEY (id);


--
-- Name: ix_attachment_entity_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_attachment_entity_id ON public.attachment USING btree (entity_id);


--
-- Name: ix_attachment_entity_type; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_attachment_entity_type ON public.attachment USING btree (entity_type);


--
-- Name: ix_audit_log_entity_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_audit_log_entity_id ON public.audit_log USING btree (entity_id);


--
-- Name: ix_audit_log_entity_type; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_audit_log_entity_type ON public.audit_log USING btree (entity_type);


--
-- Name: ix_business_domain_member_domain_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_business_domain_member_domain_id ON public.business_domain_member USING btree (domain_id);


--
-- Name: ix_business_domain_member_person_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_business_domain_member_person_id ON public.business_domain_member USING btree (person_id);


--
-- Name: ix_campaign_task_campaign_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_campaign_task_campaign_id ON public.campaign_task USING btree (campaign_id);


--
-- Name: ix_ci_category; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_ci_category ON public.ci USING btree (category);


--
-- Name: ix_ci_relationship_source_ci_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_ci_relationship_source_ci_id ON public.ci_relationship USING btree (source_ci_id);


--
-- Name: ix_ci_relationship_target_ci_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_ci_relationship_target_ci_id ON public.ci_relationship USING btree (target_ci_id);


--
-- Name: ix_cost_entry_project_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_cost_entry_project_id ON public.cost_entry USING btree (project_id);


--
-- Name: ix_idea_like_idea_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_idea_like_idea_id ON public.idea_like USING btree (idea_id);


--
-- Name: ix_in_app_notification_recipient; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_in_app_notification_recipient ON public.in_app_notification USING btree (recipient);


--
-- Name: ix_knowledge_vote_article_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_knowledge_vote_article_id ON public.knowledge_vote USING btree (article_id);


--
-- Name: ix_master_data_category; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_master_data_category ON public.master_data USING btree (category);


--
-- Name: ix_milestone_project_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_milestone_project_id ON public.milestone USING btree (project_id);


--
-- Name: ix_notification_outbox_event_type; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_notification_outbox_event_type ON public.notification_outbox USING btree (event_type);


--
-- Name: ix_perf_adjustment_period; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_perf_adjustment_period ON public.perf_adjustment USING btree (period);


--
-- Name: ix_perf_adjustment_person_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_perf_adjustment_person_id ON public.perf_adjustment USING btree (person_id);


--
-- Name: ix_perf_override_period; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_perf_override_period ON public.perf_override USING btree (period);


--
-- Name: ix_perf_override_person_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_perf_override_person_id ON public.perf_override USING btree (person_id);


--
-- Name: ix_point_entry_campaign_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_point_entry_campaign_id ON public.point_entry USING btree (campaign_id);


--
-- Name: ix_point_entry_period; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_point_entry_period ON public.point_entry USING btree (period);


--
-- Name: ix_point_entry_person_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_point_entry_person_id ON public.point_entry USING btree (person_id);


--
-- Name: ix_point_entry_source_type; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_point_entry_source_type ON public.point_entry USING btree (source_type);


--
-- Name: ix_problem_status; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_problem_status ON public.problem USING btree (status);


--
-- Name: ix_problem_ticket_problem_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_problem_ticket_problem_id ON public.problem_ticket USING btree (problem_id);


--
-- Name: ix_problem_ticket_ticket_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_problem_ticket_ticket_id ON public.problem_ticket USING btree (ticket_id);


--
-- Name: ix_process_instance_entity_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_process_instance_entity_id ON public.process_instance USING btree (entity_id);


--
-- Name: ix_process_instance_entity_type; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_process_instance_entity_type ON public.process_instance USING btree (entity_type);


--
-- Name: ix_process_task_assignee; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_process_task_assignee ON public.process_task USING btree (assignee);


--
-- Name: ix_project_portfolio_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_project_portfolio_id ON public.project USING btree (portfolio_id);


--
-- Name: ix_project_status; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_project_status ON public.project USING btree (status);


--
-- Name: ix_requirement_business_domain_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_requirement_business_domain_id ON public.requirement USING btree (business_domain_id);


--
-- Name: ix_requirement_project_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_requirement_project_id ON public.requirement USING btree (project_id);


--
-- Name: ix_requirement_status; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_requirement_status ON public.requirement USING btree (status);


--
-- Name: ix_requirement_task_requirement_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_requirement_task_requirement_id ON public.requirement_task USING btree (requirement_id);


--
-- Name: ix_risk_project_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_risk_project_id ON public.risk USING btree (project_id);


--
-- Name: ix_role_permission_role_code; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_role_permission_role_code ON public.role_permission USING btree (role_code);


--
-- Name: ix_ticket_assignee; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_ticket_assignee ON public.ticket USING btree (assignee);


--
-- Name: ix_ticket_priority; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_ticket_priority ON public.ticket USING btree (priority);


--
-- Name: ix_ticket_service_item_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_ticket_service_item_id ON public.ticket USING btree (service_item_id);


--
-- Name: ix_ticket_status; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_ticket_status ON public.ticket USING btree (status);


--
-- Name: ix_ticket_submitted_at; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_ticket_submitted_at ON public.ticket USING btree (submitted_at);


--
-- Name: ix_ticket_type_status; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_ticket_type_status ON public.ticket USING btree (ticket_type, status);


--
-- Name: ix_user_group_member_group_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_user_group_member_group_id ON public.user_group_member USING btree (group_id);


--
-- Name: ix_user_group_member_person_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_user_group_member_person_id ON public.user_group_member USING btree (person_id);


--
-- Name: ix_wbs_task_project_id; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_wbs_task_project_id ON public.wbs_task USING btree (project_id);


--
-- Name: ix_workflow_status_entity_type; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_workflow_status_entity_type ON public.workflow_status USING btree (entity_type);


--
-- Name: ix_workflow_transition_entity_type; Type: INDEX; Schema: public; Owner: aom
--

CREATE INDEX ix_workflow_transition_entity_type ON public.workflow_transition USING btree (entity_type);


--
-- Name: auth_user auth_user_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.org_member(id);


--
-- Name: business_domain business_domain_backup_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.business_domain
    ADD CONSTRAINT business_domain_backup_owner_id_fkey FOREIGN KEY (backup_owner_id) REFERENCES public.org_member(id);


--
-- Name: business_domain_member business_domain_member_domain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.business_domain_member
    ADD CONSTRAINT business_domain_member_domain_id_fkey FOREIGN KEY (domain_id) REFERENCES public.business_domain(id);


--
-- Name: business_domain_member business_domain_member_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.business_domain_member
    ADD CONSTRAINT business_domain_member_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.org_member(id);


--
-- Name: business_domain business_domain_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.business_domain
    ADD CONSTRAINT business_domain_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.org_member(id);


--
-- Name: campaign_task campaign_task_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.campaign_task
    ADD CONSTRAINT campaign_task_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.activity_campaign(id);


--
-- Name: ci ci_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.ci
    ADD CONSTRAINT ci_owner_fkey FOREIGN KEY (owner) REFERENCES public.org_member(id);


--
-- Name: ci_relationship ci_relationship_source_ci_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.ci_relationship
    ADD CONSTRAINT ci_relationship_source_ci_id_fkey FOREIGN KEY (source_ci_id) REFERENCES public.ci(id);


--
-- Name: ci_relationship ci_relationship_target_ci_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.ci_relationship
    ADD CONSTRAINT ci_relationship_target_ci_id_fkey FOREIGN KEY (target_ci_id) REFERENCES public.ci(id);


--
-- Name: ci ci_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.ci
    ADD CONSTRAINT ci_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendor(id);


--
-- Name: contract contract_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT contract_owner_fkey FOREIGN KEY (owner) REFERENCES public.org_member(id);


--
-- Name: contract contract_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT contract_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendor(id);


--
-- Name: cost_entry cost_entry_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.cost_entry
    ADD CONSTRAINT cost_entry_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id);


--
-- Name: department department_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.department
    ADD CONSTRAINT department_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.department(id);


--
-- Name: development_activity development_activity_host_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.development_activity
    ADD CONSTRAINT development_activity_host_id_fkey FOREIGN KEY (host_id) REFERENCES public.org_member(id);


--
-- Name: hiring_need hiring_need_position_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.hiring_need
    ADD CONSTRAINT hiring_need_position_id_fkey FOREIGN KEY (position_id) REFERENCES public."position"(id);


--
-- Name: idea_like idea_like_idea_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.idea_like
    ADD CONSTRAINT idea_like_idea_id_fkey FOREIGN KEY (idea_id) REFERENCES public.idea(id);


--
-- Name: in_app_notification in_app_notification_recipient_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.in_app_notification
    ADD CONSTRAINT in_app_notification_recipient_fkey FOREIGN KEY (recipient) REFERENCES public.org_member(id);


--
-- Name: knowledge_vote knowledge_vote_article_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.knowledge_vote
    ADD CONSTRAINT knowledge_vote_article_id_fkey FOREIGN KEY (article_id) REFERENCES public.knowledge_article(id);


--
-- Name: milestone milestone_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.milestone
    ADD CONSTRAINT milestone_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id);


--
-- Name: org_member org_member_position_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.org_member
    ADD CONSTRAINT org_member_position_id_fkey FOREIGN KEY (position_id) REFERENCES public."position"(id);


--
-- Name: perf_adjustment perf_adjustment_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.perf_adjustment
    ADD CONSTRAINT perf_adjustment_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.org_member(id);


--
-- Name: perf_override perf_override_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.perf_override
    ADD CONSTRAINT perf_override_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.org_member(id);


--
-- Name: point_entry point_entry_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.point_entry
    ADD CONSTRAINT point_entry_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.activity_campaign(id);


--
-- Name: point_entry point_entry_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.point_entry
    ADD CONSTRAINT point_entry_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.org_member(id);


--
-- Name: point_entry point_entry_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.point_entry
    ADD CONSTRAINT point_entry_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.campaign_task(id);


--
-- Name: portfolio portfolio_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.portfolio
    ADD CONSTRAINT portfolio_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.org_member(id);


--
-- Name: problem problem_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.problem
    ADD CONSTRAINT problem_owner_fkey FOREIGN KEY (owner) REFERENCES public.org_member(id);


--
-- Name: problem problem_service_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.problem
    ADD CONSTRAINT problem_service_item_id_fkey FOREIGN KEY (service_item_id) REFERENCES public.service_item(id);


--
-- Name: problem_ticket problem_ticket_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.problem_ticket
    ADD CONSTRAINT problem_ticket_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES public.problem(id);


--
-- Name: problem_ticket problem_ticket_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.problem_ticket
    ADD CONSTRAINT problem_ticket_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.ticket(id);


--
-- Name: process_instance process_instance_definition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.process_instance
    ADD CONSTRAINT process_instance_definition_id_fkey FOREIGN KEY (definition_id) REFERENCES public.process_definition(id);


--
-- Name: process_step process_step_definition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.process_step
    ADD CONSTRAINT process_step_definition_id_fkey FOREIGN KEY (definition_id) REFERENCES public.process_definition(id);


--
-- Name: process_task process_task_assignee_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.process_task
    ADD CONSTRAINT process_task_assignee_fkey FOREIGN KEY (assignee) REFERENCES public.org_member(id);


--
-- Name: process_task process_task_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.process_task
    ADD CONSTRAINT process_task_instance_id_fkey FOREIGN KEY (instance_id) REFERENCES public.process_instance(id);


--
-- Name: process_task process_task_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.process_task
    ADD CONSTRAINT process_task_step_id_fkey FOREIGN KEY (step_id) REFERENCES public.process_step(id);


--
-- Name: project project_pm_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pm_fkey FOREIGN KEY (pm) REFERENCES public.org_member(id);


--
-- Name: project project_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolio(id);


--
-- Name: project project_service_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_service_item_id_fkey FOREIGN KEY (service_item_id) REFERENCES public.service_item(id);


--
-- Name: requirement requirement_business_domain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.requirement
    ADD CONSTRAINT requirement_business_domain_id_fkey FOREIGN KEY (business_domain_id) REFERENCES public.business_domain(id);


--
-- Name: requirement requirement_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.requirement
    ADD CONSTRAINT requirement_owner_fkey FOREIGN KEY (owner) REFERENCES public.org_member(id);


--
-- Name: requirement requirement_parent_requirement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.requirement
    ADD CONSTRAINT requirement_parent_requirement_id_fkey FOREIGN KEY (parent_requirement_id) REFERENCES public.requirement(id);


--
-- Name: requirement requirement_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.requirement
    ADD CONSTRAINT requirement_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id);


--
-- Name: requirement_task requirement_task_assignee_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.requirement_task
    ADD CONSTRAINT requirement_task_assignee_fkey FOREIGN KEY (assignee) REFERENCES public.org_member(id);


--
-- Name: requirement_task requirement_task_requirement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.requirement_task
    ADD CONSTRAINT requirement_task_requirement_id_fkey FOREIGN KEY (requirement_id) REFERENCES public.requirement(id);


--
-- Name: risk risk_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.risk
    ADD CONSTRAINT risk_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id);


--
-- Name: service_item service_item_catalog_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.service_item
    ADD CONSTRAINT service_item_catalog_id_fkey FOREIGN KEY (catalog_id) REFERENCES public.service_catalog(id);


--
-- Name: service_item service_item_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.service_item
    ADD CONSTRAINT service_item_owner_fkey FOREIGN KEY (owner) REFERENCES public.org_member(id);


--
-- Name: ticket ticket_assignee_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.ticket
    ADD CONSTRAINT ticket_assignee_fkey FOREIGN KEY (assignee) REFERENCES public.org_member(id);


--
-- Name: ticket ticket_service_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.ticket
    ADD CONSTRAINT ticket_service_item_id_fkey FOREIGN KEY (service_item_id) REFERENCES public.service_item(id);


--
-- Name: user_group_member user_group_member_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.user_group_member
    ADD CONSTRAINT user_group_member_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.user_group(id);


--
-- Name: user_group_member user_group_member_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.user_group_member
    ADD CONSTRAINT user_group_member_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.org_member(id);


--
-- Name: wbs_task wbs_task_assignee_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.wbs_task
    ADD CONSTRAINT wbs_task_assignee_fkey FOREIGN KEY (assignee) REFERENCES public.org_member(id);


--
-- Name: wbs_task wbs_task_parent_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.wbs_task
    ADD CONSTRAINT wbs_task_parent_task_id_fkey FOREIGN KEY (parent_task_id) REFERENCES public.wbs_task(id);


--
-- Name: wbs_task wbs_task_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aom
--

ALTER TABLE ONLY public.wbs_task
    ADD CONSTRAINT wbs_task_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id);


--
-- PostgreSQL database dump complete
--

\unrestrict F6sFYp573rcmoUOQASwckkMVBBgN9vwNIfMhe5EurZLXcaZo0vB9a1CHzIf1Uyp

